<?php
/**
 * Plugin Name: CSV Importer Pro for WooCommerce
 * Plugin URI: https://your-website.com/csv-importer-pro
 * Description: Professional WooCommerce product importer — unlimited CSV files, auto-scheduling, background import, and license-based access.
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://your-website.com
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: cip-pro
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ── Constants ──
define( 'CIP_PRO_VERSION',      '1.0.0' );
define( 'CIP_PRO_DIR',          plugin_dir_path( __FILE__ ) );
define( 'CIP_PRO_URL',          plugin_dir_url( __FILE__ ) );
define( 'CIP_PRO_BATCH_SIZE',   50 );
define( 'CIP_PRO_BATCH_DELAY',  2 );
define( 'CIP_PRO_CSV_FOLDER',   'cip-pro-csv/' );
define( 'CIP_PRO_IMAGE_FOLDER', 'cip-pro-images/' );
define( 'CIP_PRO_LOG_FOLDER',   'cip-pro-logs/' );

// ── Load modules ──
require_once CIP_PRO_DIR . 'includes/class-cipro-license.php';
require_once CIP_PRO_DIR . 'includes/class-cipro-logger.php';
require_once CIP_PRO_DIR . 'includes/class-cipro-file-manager.php';
require_once CIP_PRO_DIR . 'includes/class-cipro-csv-parser.php';
require_once CIP_PRO_DIR . 'includes/class-cipro-product.php';
require_once CIP_PRO_DIR . 'includes/class-cipro-cron.php';
require_once CIP_PRO_DIR . 'includes/class-cipro-ajax.php';
require_once CIP_PRO_DIR . 'includes/class-cipro-admin.php';

/**
 * Main Plugin Bootstrap
 */
final class CSV_Importer_Pro_Woo {

    public static $instance = null;

    public $license;
    public $logger;
    public $file_manager;
    public $parser;
    public $product;
    public $cron;
    public $ajax;
    public $admin;

    private $upload_dir;

    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->upload_dir = wp_upload_dir();

        $this->license      = new CIPRO_License();
        $this->logger       = new CIPRO_Logger( $this->get_path( 'log' ) );
        $this->file_manager = new CIPRO_File_Manager( $this->logger );
        $this->parser       = new CIPRO_CSV_Parser( $this->logger );
        $this->product      = new CIPRO_Product( $this->logger, $this->get_path( 'image' ) );
        $this->cron         = new CIPRO_Cron( $this->logger );
        $this->ajax         = new CIPRO_Ajax( $this->logger, $this->parser, $this->product, $this->file_manager, $this->license );
        $this->admin        = new CIPRO_Admin( $this->logger, $this->file_manager, $this->license );

        add_action( 'init', [ $this, 'init' ] );
        register_activation_hook( __FILE__,   [ $this, 'activate' ] );
        register_deactivation_hook( __FILE__, [ $this, 'deactivate' ] );
    }

    public function get_path( $type ) {
        $base = trailingslashit( $this->upload_dir['basedir'] );
        switch ( $type ) {
            case 'csv':   return $base . CIP_PRO_CSV_FOLDER;
            case 'image': return $base . CIP_PRO_IMAGE_FOLDER;
            case 'log':   return $base . CIP_PRO_LOG_FOLDER;
            default:      return $base;
        }
    }

    public function init() {
        // Create folders
        foreach ( [ 'csv', 'image', 'log' ] as $f ) {
            wp_mkdir_p( $this->get_path( $f ) );
        }

        // Register cron hooks (only if license is active)
        if ( $this->license->is_active() ) {
            $this->cron->register_hooks();
            add_action( 'cipro_scheduled_import',  [ $this, 'run_scheduled_import' ] );
            add_action( 'cipro_background_import', [ $this, 'run_background_import' ] );
        }

        // Admin UI
        add_action( 'admin_menu', [ $this->admin, 'add_admin_menu' ] );

        // AJAX handlers
        add_action( 'wp_ajax_cipro_manual_import',   [ $this->ajax, 'handle_manual_import' ] );
        add_action( 'wp_ajax_cipro_view_logs',       [ $this->ajax, 'handle_view_logs' ] );
        add_action( 'wp_ajax_cipro_delete_all',      [ $this->ajax, 'handle_delete_all' ] );
        add_action( 'wp_ajax_cipro_download_file',   [ $this->ajax, 'handle_download_file' ] );
        add_action( 'wp_ajax_cipro_delete_csv_file', [ $this->ajax, 'handle_delete_csv_file' ] );
        add_action( 'wp_ajax_cipro_save_mapping',    [ $this->ajax, 'handle_save_mapping' ] );
        add_action( 'wp_ajax_cipro_detect_columns',  [ $this->ajax, 'handle_detect_columns' ] );
        add_action( 'wp_ajax_cipro_activate_license',[ $this->ajax, 'handle_activate_license' ] );
        add_action( 'wp_ajax_cipro_deactivate_license',[ $this->ajax, 'handle_deactivate_license' ] );
    }

    public function activate() {
        foreach ( [ 'csv', 'image', 'log' ] as $f ) {
            wp_mkdir_p( $this->get_path( $f ) );
        }
    }

    public function deactivate() {
        $this->cron->deactivate();
    }

    // ── Import runners ──

    public function run_scheduled_import() {
        if ( ! $this->license->is_active() ) {
            $this->logger->error( 'Scheduled import blocked — license not active.' );
            return;
        }
        $this->logger->info( '=== Scheduled import triggered ===' );
        // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        @set_time_limit( 0 );
        // phpcs:ignore WordPress.PHP.IniSet.memory_limit_Blacklisted
        @ini_set( 'memory_limit', '2048M' ); // @codingStandardsIgnoreLine
        $this->run_all_imports();
    }

    public function run_background_import() {
        if ( ! $this->license->is_active() ) return;
        $this->logger->info( '=== Background import started ===' );
        // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        @set_time_limit( 0 );
        // phpcs:ignore WordPress.PHP.IniSet.memory_limit_Blacklisted
        @ini_set( 'memory_limit', '2048M' ); // @codingStandardsIgnoreLine
        wp_cache_flush();
        $this->run_all_imports();
        wp_cache_flush();
        $this->logger->info( '=== Background import completed ===' );
    }

    /**
     * Run import for ALL uploaded CSV files
     */
    public function run_all_imports() {
        // Prevent concurrent runs
        $lock = get_transient( 'cipro_import_running' );
        if ( $lock ) {
            if ( ( time() - $lock ) < 3600 ) {
                $this->logger->error( 'Import already running — skipped.' );
                return;
            }
            delete_transient( 'cipro_import_running' );
        }

        set_transient( 'cipro_import_running', time(), 7200 );

        register_shutdown_function( function() {
            $err = error_get_last();
            if ( $err && in_array( $err['type'], [ E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR ], true ) ) {
                delete_transient( 'cipro_import_running' );
            }
        } );

        $this->logger->info( str_repeat( '=', 50 ) );
        $this->logger->info( 'CSV IMPORTER PRO — STARTING' );
        $this->logger->info( str_repeat( '=', 50 ) );

        $start     = microtime( true );
        $csv_files = glob( $this->get_path( 'csv' ) . '*.csv' );
        $totals    = [ 'processed' => 0, 'created' => 0, 'updated' => 0, 'skipped' => 0, 'errors' => 0 ];

        if ( empty( $csv_files ) ) {
            $this->logger->error( 'No CSV files found.' );
            delete_transient( 'cipro_import_running' );
            return;
        }

        foreach ( $csv_files as $file ) {
            $stats = $this->import_single_file( $file );
            foreach ( array_keys( $totals ) as $k ) {
                $totals[ $k ] += $stats[ $k ];
            }
        }

        $duration = round( microtime( true ) - $start, 2 );
        $this->logger->info( "COMPLETE in {$duration}s | Processed:{$totals['processed']} Created:{$totals['created']} Updated:{$totals['updated']} Skipped:{$totals['skipped']} Errors:{$totals['errors']}" );
        $this->logger->info( str_repeat( '=', 50 ) );

        delete_transient( 'cipro_import_running' );
        return $totals;
    }

    /**
     * Import a single CSV file
     */
    public function import_single_file( $file_path ) {
        $stats    = [ 'processed' => 0, 'created' => 0, 'updated' => 0, 'skipped' => 0, 'errors' => 0 ];
        $filename = basename( $file_path );

        if ( ! file_exists( $file_path ) ) {
            $this->logger->error( "File not found: {$file_path}" );
            return $stats;
        }

        $this->logger->info( "[{$filename}] Starting — " . round( filesize( $file_path ) / 1024 / 1024, 2 ) . ' MB' );

        $mapping = $this->parser->get_mapping_for_file( $filename );
        $rows    = $this->parser->read_csv( $file_path, $mapping );

        if ( $rows === false ) {
            $this->logger->error( "[{$filename}] Parse failed" );
            return $stats;
        }

        $this->logger->info( "[{$filename}] " . count( $rows ) . ' rows to process' );
        $seen_skus = [];

        foreach ( $rows as $i => $row ) {
            try {
                $sku  = sanitize_text_field( trim( $row['sku']  ?? '' ) );
                $name = sanitize_text_field( trim( $row['name'] ?? '' ) );

                if ( strlen( $sku ) < 2 )                                                     { $stats['skipped']++; continue; }
                if ( empty( $name ) )                                                          { $stats['skipped']++; continue; }
                if ( ! is_numeric( $row['price'] ?? '' ) || floatval( $row['price'] ) < 0 )   { $stats['skipped']++; continue; }
                if ( isset( $seen_skus[ $sku ] ) )                                            { $stats['skipped']++; continue; }

                $seen_skus[ $sku ] = true;

                $existing_id = wc_get_product_id_by_sku( $sku );
                if ( ! $existing_id ) {
                    global $wpdb;
                    $existing_id = $wpdb->get_var( $wpdb->prepare(
                        "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_sku' AND meta_value=%s LIMIT 1", $sku
                    ) );
                }

                if ( $existing_id ) {
                    $this->product->update_product( $existing_id, $row ) ? $stats['updated']++ : $stats['skipped']++;
                } else {
                    $this->product->create_product( $row ) ? $stats['created']++ : $stats['errors']++;
                }

                $stats['processed']++;

                if ( $stats['processed'] % CIP_PRO_BATCH_SIZE === 0 ) {
                    $this->logger->info( "[{$filename}] Batch {$stats['processed']} — Mem: " . round( memory_get_usage() / 1024 / 1024, 1 ) . 'MB' );
                    wp_cache_flush();
                    sleep( CIP_PRO_BATCH_DELAY );
                }

            } catch ( \Throwable $e ) {
                $this->logger->error( "[{$filename}] Row {$i}: " . $e->getMessage() );
                $stats['errors']++;
            }
        }

        $this->logger->info( "[{$filename}] Done — P:{$stats['processed']} C:{$stats['created']} U:{$stats['updated']} S:{$stats['skipped']} E:{$stats['errors']}" );
        return $stats;
    }
}

// Boot
CSV_Importer_Pro_Woo::get_instance();
