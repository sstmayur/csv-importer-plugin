=== CSV Importer Pro for WooCommerce ===
Contributors: yourwordpressusername
Tags: woocommerce, csv import, product import, bulk import, scheduled import, auto import
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Professional WooCommerce CSV importer — unlimited files, auto-scheduling, background import, smart column mapping, and license-based access.

== Description ==

**CSV Importer Pro** is the most powerful CSV product importer for WooCommerce. Upload multiple CSV files, auto-detect columns, set up recurring schedules, and let the plugin keep your store updated — automatically.

= Pro Features =

* **Unlimited CSV Files** — Upload as many as you need
* **Auto-Scheduling** — Hourly, daily, weekly automatic imports via WordPress Cron
* **Background Import** — Runs without keeping browser open; safe for 100,000+ rows
* **Smart Column Mapping** — Per-file or global; auto-matches common column names
* **License System** — Secure activation via your own license server
* **Batch processing** — 50 products per batch with memory management
* **Detailed Logs** — Full import history with timestamps
* **15 Mappable Fields** — SKU, Name, Price, Sale Price, Description, Short Description, Stock, Category, Tag, Weight, Length, Width, Height, Image URL, External URL
* **Danger Zone** — Bulk delete all products

= How Scheduling Works =

1. Upload your CSV files
2. Configure column mapping
3. Go to Auto-Schedule tab and set frequency + time
4. Plugin automatically processes all CSV files at the scheduled time via WP Cron
5. Check Logs tab to view results

== Installation ==

1. Purchase a license at https://your-website.com/csv-importer-pro
2. Upload the plugin ZIP via WordPress → Plugins → Add New
3. Activate the plugin
4. Go to WooCommerce → CSV Importer Pro
5. Enter your license key in the License tab and activate

== Frequently Asked Questions ==

= Does this work without a license key? =
You can install the plugin, but all features require an active license key.

= How do I set up automatic imports? =
Go to the Auto-Schedule tab, choose frequency (hourly/daily/weekly), set a time, and save. The plugin will run automatically.

= Can each CSV file have different column names? =
Yes. The plugin supports per-file column mapping. Each file can have a completely different structure.

= What happens if a product already exists? =
Products are matched by SKU. If a match is found, the product is updated. If not, a new product is created.

= How do I add product images? =
Either upload a ZIP file with images named after the product SKU, or include an Image URL column in your CSV.

== Changelog ==

= 1.0.0 =
* Initial Pro release
* License key activation system
* Auto-scheduling (hourly, daily, weekly, monthly)
* Background import via WP Cron
* Unlimited CSV file support
* Per-file column mapping with auto-detection
* 15 mappable WooCommerce fields
