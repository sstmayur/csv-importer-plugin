<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * CIPRO_CSV_Parser
 * Reads CSV files and maps columns based on saved settings.
 * Supports per-file column mapping OR global mapping.
 */
class CIPRO_CSV_Parser {

    private $logger;

    public function __construct( $logger ) {
        $this->logger = $logger;
    }

    /**
     * Get column mapping for a specific file.
     * Falls back to global mapping if no per-file mapping saved.
     */
    public function get_mapping_for_file( $filename ) {
        $per_file = get_option( 'cipro_file_mappings', [] );
        if ( isset( $per_file[ $filename ] ) ) {
            return $per_file[ $filename ];
        }
        return get_option( 'cipro_column_mapping', $this->default_mapping() );
    }

    /**
     * Save mapping for a specific file
     */
    public function save_mapping_for_file( $filename, $mapping ) {
        $per_file              = get_option( 'cipro_file_mappings', [] );
        $per_file[ $filename ] = $mapping;
        update_option( 'cipro_file_mappings', $per_file );
    }

    /**
     * Save global mapping
     */
    public function save_global_mapping( $mapping ) {
        update_option( 'cipro_column_mapping', $mapping );
    }

    /**
     * Default column mapping
     */
    public function default_mapping() {
        return [
            'sku'         => 'SKU',
            'name'        => 'Name',
            'description' => 'Description',
            'price'       => 'Price',
            'stock'       => 'Stock',
            'category'    => 'Category',
        ];
    }

    /**
     * Read CSV file and return mapped rows
     *
     * @param string $file_path  Full path to CSV
     * @param array  $mapping    Column mapping [ 'sku' => 'CSV_Column_Name', ... ]
     * @return array|false
     */
    public function read_csv( $file_path, $mapping ) {
        // phpcs:ignore WordPress.PHP.IniSet.Risky -- Required for cross-platform CSV line ending support
        @ini_set( 'auto_detect_line_endings', true ); // @codingStandardsIgnoreLine

        if ( ! file_exists( $file_path ) || ! is_readable( $file_path ) ) {
            $this->logger->error( "File not found/readable: {$file_path}" );
            return false;
        }

        $handle = fopen( $file_path, 'r' );
        if ( $handle === false ) {
            $this->logger->error( "Could not open: {$file_path}" );
            return false;
        }

        // Read & clean headers
        $raw_headers = fgetcsv( $handle );
        if ( ! $raw_headers ) {
            $this->logger->error( "No headers in: {$file_path}" );
            fclose( $handle );
            return false;
        }

        $headers = array_map( function ( $h ) {
            $h = preg_replace( '/^\xEF\xBB\xBF/', '', $h );
            $h = str_replace( "\x00", '', $h );
            return trim( $h );
        }, $raw_headers );

        $this->logger->info( basename( $file_path ) . ' — ' . count( $headers ) . ' columns detected' );

        $rows     = [];
        $row_num  = 1;
        $skipped  = 0;

        while ( ( $row = fgetcsv( $handle ) ) !== false ) {
            $row_num++;
            if ( empty( array_filter( $row ) ) ) continue;

            if ( count( $headers ) !== count( $row ) ) {
                $skipped++;
                continue;
            }

            $data   = array_combine( $headers, $row );
            $mapped = $this->map_row( $data, $mapping );

            if ( $mapped !== null ) {
                $rows[] = $mapped;
            }
        }

        fclose( $handle );

        if ( $skipped > 0 ) {
            $this->logger->warning( basename( $file_path ) . " — {$skipped} rows skipped (column mismatch)" );
        }

        $this->logger->info( basename( $file_path ) . ' — ' . count( $rows ) . ' valid rows parsed' );
        return $rows;
    }

    /**
     * Map a single CSV row to product fields
     *
     * @param array $data     Associative array ( CSV column => value )
     * @param array $mapping  ( product_field => CSV column name )
     * @return array|null
     */
    public function map_row( $data, $mapping ) {
        $mapped = [];

        foreach ( $mapping as $field => $csv_col ) {
            if ( ! empty( $csv_col ) && isset( $data[ $csv_col ] ) ) {
                $mapped[ $field ] = trim( $data[ $csv_col ] );
            }
        }

        // Required: sku + name
        if ( empty( $mapped['sku'] ) || empty( $mapped['name'] ) ) {
            return null;
        }

        // Default price
        if ( ! isset( $mapped['price'] ) ) {
            $mapped['price'] = '0';
        }

        return $mapped;
    }

    /**
     * Read raw CSV for AJAX batch processing
     * Returns headers + data rows (not mapped)
     */
    public function read_raw( $file_path ) {
        if ( ! file_exists( $file_path ) ) return false;

        $handle = fopen( $file_path, 'r' );
        if ( ! $handle ) return false;

        $raw_headers = fgetcsv( $handle );
        $headers     = array_map( function( $h ) {
            $h = preg_replace( '/^\xEF\xBB\xBF/', '', $h );
            return trim( $h );
        }, $raw_headers );

        $rows = [];
        while ( ( $row = fgetcsv( $handle ) ) !== false ) {
            if ( ! empty( array_filter( $row ) ) ) {
                $rows[] = $row;
            }
        }
        fclose( $handle );

        return [ 'headers' => $headers, 'rows' => $rows ];
    }
}
