<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class CIPRO_Admin {

    private $logger;
    private $file_manager;
    private $license;

    public function __construct( $logger, $file_manager, $license ) {
        $this->logger       = $logger;
        $this->file_manager = $file_manager;
        $this->license      = $license;
    }

    public function add_admin_menu() {
        add_submenu_page(
            'woocommerce',
            __( 'CSV Importer Pro', 'cip-pro' ),
            __( 'CSV Importer Pro', 'cip-pro' ),
            'manage_woocommerce',
            'csv-importer-pro-woo',
            [ $this, 'render_page' ]
        );
    }

    public function render_page() {
        $this->handle_form_submissions();
        $active_tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'files';
        $base_url   = admin_url( 'admin.php?page=csv-importer-pro-woo' );
        $is_active  = $this->license->is_active();

        $tabs = [
            'files'    => '📂 ' . __( 'CSV Files',      'cip-pro' ),
            'mapping'  => '🔗 ' . __( 'Column Mapping', 'cip-pro' ),
            'import'   => '▶ '  . __( 'Run Import',     'cip-pro' ),
            'images'   => '🖼 '  . __( 'Images',         'cip-pro' ),
            'schedule' => '⏰ '  . __( 'Auto-Schedule',  'cip-pro' ),
            'logs'     => '📋 '  . __( 'Logs',           'cip-pro' ),
            'danger'   => '⚠ '   . __( 'Danger Zone',   'cip-pro' ),
            'license'  => '🔑 '  . __( 'License',        'cip-pro' ),
        ];
        ?>
        <div class="wrap">
            <h1 style="display:flex;align-items:center;gap:10px;">
                <span class="dashicons dashicons-database-import" style="font-size:30px;color:#2271b1;"></span>
                <?php esc_html_e( 'CSV Importer Pro for WooCommerce', 'cip-pro' ); ?>
                <span style="font-size:11px;background:#f59e0b;color:#fff;padding:2px 10px;border-radius:10px;font-weight:700;">PRO</span>
                <span style="font-size:12px;color:#646970;">v<?php echo esc_html( CIP_PRO_VERSION ); ?></span>
                <?php if ( $is_active ) : ?>
                    <span style="font-size:12px;color:#00a32a;font-weight:600;">✅ <?php esc_html_e( 'License Active', 'cip-pro' ); ?></span>
                <?php else : ?>
                    <span style="font-size:12px;color:#d63638;font-weight:600;">⚠ <a href="<?php echo esc_url( $base_url . '&tab=license' ); ?>"><?php esc_html_e( 'Activate License', 'cip-pro' ); ?></a></span>
                <?php endif; ?>
            </h1>

            <?php $this->render_styles(); ?>

            <?php if ( ! $is_active ) : ?>
            <div class="notice notice-error" style="padding:14px 16px;display:flex;align-items:center;gap:12px;">
                <strong>🔑 <?php esc_html_e( 'License Required:', 'cip-pro' ); ?></strong>
                <?php esc_html_e( 'Please activate your Pro license to use all features.', 'cip-pro' ); ?>
                <a href="<?php echo esc_url( $base_url . '&tab=license' ); ?>" class="button button-primary" style="margin-left:8px;"><?php esc_html_e( 'Activate Now →', 'cip-pro' ); ?></a>
            </div>
            <?php endif; ?>

            <nav class="cipro-tabs">
                <?php foreach ( $tabs as $slug => $label ) : ?>
                    <a href="<?php echo esc_url( $base_url . '&tab=' . $slug ); ?>"
                       class="cipro-tab <?php echo $active_tab === $slug ? 'active' : ''; // phpcs:ignore ?><?php echo $slug === 'license' ? ' cipro-tab-license' : ''; ?>">
                        <?php echo esc_html( $label ); ?>
                    </a>
                <?php endforeach; ?>
            </nav>

            <div class="cipro-tab-content">
                <?php
                if ( ! $is_active && ! in_array( $active_tab, [ 'license' ], true ) ) {
                    echo '<div style="padding:40px;text-align:center;color:#646970;">';
                    echo '<div style="font-size:48px;margin-bottom:16px;">🔒</div>';
                    echo '<h2>' . esc_html__( 'License Required', 'cip-pro' ) . '</h2>';
                    echo '<p>' . esc_html__( 'Activate your Pro license to unlock all features.', 'cip-pro' ) . '</p>';
                    echo '<a href="' . esc_url( $base_url . '&tab=license' ) . '" class="button button-primary button-large">' . esc_html__( 'Activate License →', 'cip-pro' ) . '</a>';
                    echo '</div>';
                } else {
                    switch ( $active_tab ) {
                        case 'files':    $this->render_files_tab();    break;
                        case 'mapping':  $this->render_mapping_tab();  break;
                        case 'import':   $this->render_import_tab();   break;
                        case 'images':   $this->render_images_tab();   break;
                        case 'schedule': $this->render_schedule_tab(); break;
                        case 'logs':     $this->render_logs_tab();     break;
                        case 'danger':   $this->render_danger_tab();   break;
                        case 'license':  $this->render_license_tab();  break;
                    }
                }
                ?>
            </div>
        </div>
        <?php $this->render_javascript( $active_tab ); ?>
        <?php
    }

    // ─────────────────────────────────────────
    //  FORM SUBMISSIONS
    // ─────────────────────────────────────────

    private function handle_form_submissions() {
        if ( isset( $_POST['cipro_upload_csv'] ) && check_admin_referer( 'cipro_upload_csv', 'cipro_csv_nonce' ) ) {
            if ( ! empty( $_FILES['cipro_csv_files']['name'] ) ) {
                $custom = isset( $_POST['cipro_custom_filename'] ) ? sanitize_text_field( $_POST['cipro_custom_filename'] ) : '';
                $result = $this->file_manager->upload_csv( 'cipro_csv_files', $custom );
                if ( ! empty( $result['uploaded'] ) ) {
                    add_settings_error( 'cipro', 'ok', '✅ Uploaded: ' . implode( ', ', $result['uploaded'] ), 'success' );
                }
                foreach ( $result['errors'] as $e ) {
                    add_settings_error( 'cipro', 'err', '❌ ' . $e, 'error' );
                }
            }
        }

        if ( isset( $_POST['cipro_save_schedule'] ) && check_admin_referer( 'cipro_schedule', 'cipro_schedule_nonce' ) ) {
            $freq = isset( $_POST['cipro_frequency'] ) ? sanitize_key( $_POST['cipro_frequency'] ) : 'daily';
            $time = isset( $_POST['cipro_time'] )      ? sanitize_text_field( $_POST['cipro_time'] ) : '02:00';
            update_option( 'cipro_cron_schedule', $freq );
            update_option( 'cipro_cron_time',     $time );
            $plugin = CSV_Importer_Pro_Woo::get_instance();
            $plugin->cron->reschedule();
            add_settings_error( 'cipro', 'sched_ok', '✅ ' . __( 'Schedule saved! Next run: ', 'cip-pro' ) . $plugin->cron->get_next_run(), 'success' );
        }

        if ( isset( $_POST['cipro_upload_images'] ) && check_admin_referer( 'cipro_upload_images', 'cipro_images_nonce' ) ) {
            $result = $this->file_manager->upload_images_zip( 'cipro_images_zip' );
            if ( $result['success'] ) {
                add_settings_error( 'cipro', 'img_ok', '✅ Extracted ' . $result['extracted'] . ' images.', 'success' );
            } else {
                add_settings_error( 'cipro', 'img_err', '❌ ' . ( $result['error'] ?? 'Error' ), 'error' );
            }
        }

        settings_errors( 'cipro' );
    }

    // ─────────────────────────────────────────
    //  TAB: FILES
    // ─────────────────────────────────────────

    private function render_files_tab() {
        $files = $this->file_manager->list_csv_files();
        ?>
        <div class="cipro-card">
            <h2>📂 <?php esc_html_e( 'Upload CSV Files', 'cip-pro' ); ?></h2>
            <p style="color:#646970;"><?php esc_html_e( 'Upload one or more CSV files. Pro supports unlimited files.', 'cip-pro' ); ?></p>

            <form method="post" enctype="multipart/form-data">
                <?php wp_nonce_field( 'cipro_upload_csv', 'cipro_csv_nonce' ); ?>
                <div class="cipro-form-row">
                    <label><strong><?php esc_html_e( 'Select CSV File(s)', 'cip-pro' ); ?></strong>
                        <p class="description"><?php esc_html_e( 'Select multiple files by holding Ctrl/Cmd.', 'cip-pro' ); ?></p>
                        <input type="file" name="cipro_csv_files[]" accept=".csv" multiple style="margin-top:8px;width:100%;max-width:520px;">
                    </label>
                </div>
                <div class="cipro-form-row">
                    <label><strong><?php esc_html_e( 'Custom Filename', 'cip-pro' ); ?></strong>
                        <p class="description"><?php esc_html_e( 'Optional. Used only when uploading a single file.', 'cip-pro' ); ?></p>
                        <input type="text" name="cipro_custom_filename" placeholder="products.csv" style="margin-top:6px;width:100%;max-width:400px;">
                    </label>
                </div>
                <button type="submit" name="cipro_upload_csv" class="button button-primary">⬆ <?php esc_html_e( 'Upload', 'cip-pro' ); ?></button>
            </form>
        </div>

        <div class="cipro-card">
            <h2>📄 <?php esc_html_e( 'Uploaded Files', 'cip-pro' ); ?> <span style="background:#2271b1;color:#fff;font-size:12px;padding:2px 8px;border-radius:10px;margin-left:6px;"><?php echo esc_html( count( $files ) ); ?></span></h2>
            <?php if ( empty( $files ) ) : ?>
                <p style="color:#646970;"><?php esc_html_e( 'No CSV files uploaded yet.', 'cip-pro' ); ?></p>
            <?php else : ?>
            <table class="cipro-table widefat striped">
                <thead><tr>
                    <th><?php esc_html_e( 'Filename', 'cip-pro' ); ?></th>
                    <th><?php esc_html_e( 'Size', 'cip-pro' ); ?></th>
                    <th><?php esc_html_e( 'Rows', 'cip-pro' ); ?></th>
                    <th><?php esc_html_e( 'Modified', 'cip-pro' ); ?></th>
                    <th><?php esc_html_e( 'Mapping', 'cip-pro' ); ?></th>
                    <th><?php esc_html_e( 'Actions', 'cip-pro' ); ?></th>
                </tr></thead>
                <tbody>
                    <?php
                    $file_maps = get_option( 'cipro_file_mappings', [] );
                    foreach ( $files as $f ) :
                        $has_map = ! empty( $file_maps[ $f['name'] ] );
                    ?>
                    <tr>
                        <td><strong><?php echo esc_html( $f['name'] ); ?></strong></td>
                        <td><?php echo esc_html( $f['size'] ); ?></td>
                        <td><?php echo esc_html( number_format( $f['rows'] ) ); ?></td>
                        <td style="font-size:12px;color:#646970;"><?php echo esc_html( $f['modified'] ); ?></td>
                        <td>
                            <?php if ( $has_map ) : ?>
                                <span style="color:#00a32a;font-weight:600;">✅ <?php esc_html_e( 'Mapped', 'cip-pro' ); ?></span>
                            <?php else : ?>
                                <span style="color:#f59e0b;">⚠ <?php esc_html_e( 'Not mapped', 'cip-pro' ); ?></span>
                            <?php endif; ?>
                        </td>
                        <td style="white-space:nowrap;">
                            <a href="<?php echo esc_url( admin_url( 'admin-ajax.php?action=cipro_download_file&file=' . urlencode( $f['name'] ) . '&_wpnonce=' . wp_create_nonce( 'cipro_download_csv' ) ) ); ?>" class="button button-small">⬇</a>
                            <button class="button button-small cipro-delete-file" data-file="<?php echo esc_attr( $f['name'] ); ?>" style="color:#d63638;border-color:#d63638;">🗑</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
        <?php
    }

    // ─────────────────────────────────────────
    //  TAB: MAPPING
    // ─────────────────────────────────────────

    private function render_mapping_tab() {
        $files      = $this->file_manager->list_csv_files();
        $file_maps  = get_option( 'cipro_file_mappings', [] );
        $global_map = get_option( 'cipro_column_mapping', [] );

        $wc_fields = [
            'sku'              => [ 'label' => 'SKU',              'required' => true,  'icon' => '🔑' ],
            'name'             => [ 'label' => 'Product Name',     'required' => true,  'icon' => '📦' ],
            'price'            => [ 'label' => 'Regular Price',    'required' => true,  'icon' => '💰' ],
            'sale_price'       => [ 'label' => 'Sale Price',       'required' => false, 'icon' => '🔖' ],
            'description'      => [ 'label' => 'Description',      'required' => false, 'icon' => '📝' ],
            'short_description'=> [ 'label' => 'Short Description','required' => false, 'icon' => '📄' ],
            'stock'            => [ 'label' => 'Stock Quantity',   'required' => false, 'icon' => '📊' ],
            'category'         => [ 'label' => 'Category',         'required' => false, 'icon' => '🗂' ],
            'group'            => [ 'label' => 'Tag / Group',      'required' => false, 'icon' => '🏷' ],
            'weight'           => [ 'label' => 'Weight',           'required' => false, 'icon' => '⚖' ],
            'length'           => [ 'label' => 'Length',           'required' => false, 'icon' => '📏' ],
            'width'            => [ 'label' => 'Width',            'required' => false, 'icon' => '📐' ],
            'height'           => [ 'label' => 'Height',           'required' => false, 'icon' => '📐' ],
            'image_url'        => [ 'label' => 'Image URL',        'required' => false, 'icon' => '🖼' ],
            'external_url'     => [ 'label' => 'External URL',     'required' => false, 'icon' => '🔗' ],
        ];
        ?>
        <div class="cipro-card">
            <h2>🔗 <?php esc_html_e( 'Column Mapping', 'cip-pro' ); ?></h2>
            <p><?php esc_html_e( 'Select a CSV file → columns auto-detected → match to WooCommerce fields. Each file can have its own mapping.', 'cip-pro' ); ?></p>

            <?php if ( empty( $files ) ) : ?>
                <div class="notice notice-warning inline"><p><?php esc_html_e( 'Upload a CSV file first.', 'cip-pro' ); ?></p></div>
            <?php else : ?>

            <!-- Step 1 -->
            <div class="cipro-step-box">
                <div class="cipro-step-num">1</div>
                <div style="flex:1;">
                    <strong><?php esc_html_e( 'Select CSV File', 'cip-pro' ); ?></strong>
                    <div style="margin-top:10px;display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                        <select id="cipro-mapping-file" style="min-width:260px;height:36px;">
                            <option value=""><?php esc_html_e( '— Choose a file —', 'cip-pro' ); ?></option>
                            <?php foreach ( $files as $f ) : ?>
                                <option value="<?php echo esc_attr( $f['name'] ); ?>"><?php echo esc_html( $f['name'] ); ?> (<?php echo esc_html( number_format( $f['rows'] ) ); ?> rows)</option>
                            <?php endforeach; ?>
                        </select>
                        <button type="button" class="button button-primary" id="cipro-load-columns" disabled>🔍 <?php esc_html_e( 'Load Columns', 'cip-pro' ); ?></button>
                        <span id="cipro-loading-cols" style="display:none;color:#646970;"><span class="spinner is-active" style="float:none;vertical-align:middle;margin:0 4px 0 0;"></span><?php esc_html_e( 'Detecting...', 'cip-pro' ); ?></span>
                    </div>
                </div>
            </div>

            <!-- Mapping UI -->
            <div id="cipro-mapping-ui" style="display:none;margin-top:20px;">
                <div class="cipro-step-box" style="align-items:flex-start;">
                    <div class="cipro-step-num">2</div>
                    <div style="flex:1;">
                        <strong><?php esc_html_e( 'Match CSV Columns → WooCommerce Fields', 'cip-pro' ); ?></strong>
                        <p style="color:#646970;font-size:13px;margin:4px 0 14px;"><?php esc_html_e( 'Auto-matched columns are highlighted. Adjust any that need fixing.', 'cip-pro' ); ?></p>

                        <div class="cipro-mapping-wrapper">
                            <div class="cipro-map-section-title">🔴 <?php esc_html_e( 'Required Fields', 'cip-pro' ); ?></div>
                            <?php foreach ( $wc_fields as $fk => $fi ) : if ( ! $fi['required'] ) continue; ?>
                            <div class="cipro-map-row required" data-field="<?php echo esc_attr( $fk ); ?>">
                                <div class="cipro-wc-field">
                                    <span class="cipro-field-icon"><?php echo esc_html( $fi['icon'] ); ?></span>
                                    <div><strong><?php echo esc_html( $fi['label'] ); ?></strong><span class="cipro-req-badge">Required</span></div>
                                </div>
                                <div class="cipro-arrow">→</div>
                                <div class="cipro-csv-col">
                                    <select class="cipro-col-select" data-field="<?php echo esc_attr( $fk ); ?>">
                                        <option value=""><?php esc_html_e( '— Select CSV column —', 'cip-pro' ); ?></option>
                                    </select>
                                    <div class="cipro-col-preview" style="display:none;"></div>
                                </div>
                            </div>
                            <?php endforeach; ?>

                            <div class="cipro-map-section-title" style="margin-top:16px;">🔵 <?php esc_html_e( 'Optional Fields', 'cip-pro' ); ?></div>
                            <?php foreach ( $wc_fields as $fk => $fi ) : if ( $fi['required'] ) continue; ?>
                            <div class="cipro-map-row" data-field="<?php echo esc_attr( $fk ); ?>">
                                <div class="cipro-wc-field">
                                    <span class="cipro-field-icon"><?php echo esc_html( $fi['icon'] ); ?></span>
                                    <strong><?php echo esc_html( $fi['label'] ); ?></strong>
                                </div>
                                <div class="cipro-arrow">→</div>
                                <div class="cipro-csv-col">
                                    <select class="cipro-col-select" data-field="<?php echo esc_attr( $fk ); ?>">
                                        <option value=""><?php esc_html_e( 'Do Not Import', 'cip-pro' ); ?></option>
                                    </select>
                                    <div class="cipro-col-preview" style="display:none;"></div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>

                        <div id="cipro-unmapped-box" style="display:none;margin-top:16px;padding:12px 16px;background:#fff8e1;border-left:4px solid #f59e0b;border-radius:4px;">
                            <strong>📋 <?php esc_html_e( 'Unused CSV columns:', 'cip-pro' ); ?></strong>
                            <div id="cipro-unmapped-list" style="margin-top:8px;display:flex;flex-wrap:wrap;gap:6px;"></div>
                        </div>
                    </div>
                </div>

                <div class="cipro-step-box" style="margin-top:12px;">
                    <div class="cipro-step-num">3</div>
                    <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
                        <button type="button" class="button button-primary button-large" id="cipro-save-mapping">💾 <?php esc_html_e( 'Save Mapping', 'cip-pro' ); ?></button>
                        <span id="cipro-mapping-saved" style="color:#00a32a;font-weight:600;display:none;">✅ <?php esc_html_e( 'Mapping saved!', 'cip-pro' ); ?></span>
                    </div>
                </div>
            </div>

            <!-- Saved mappings overview -->
            <?php if ( ! empty( $file_maps ) ) : ?>
            <div style="margin-top:28px;">
                <h3 style="font-size:14px;color:#1d2327;border-bottom:1px solid #f0f0f1;padding-bottom:8px;">💾 <?php esc_html_e( 'Saved Mappings', 'cip-pro' ); ?></h3>
                <table class="cipro-table widefat striped">
                    <thead><tr>
                        <th><?php esc_html_e( 'File', 'cip-pro' ); ?></th>
                        <th><?php esc_html_e( 'Mapped Fields', 'cip-pro' ); ?></th>
                        <th><?php esc_html_e( 'Action', 'cip-pro' ); ?></th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ( $file_maps as $fname => $fmap ) :
                        $mapped = array_filter( $fmap );
                    ?>
                    <tr>
                        <td><strong><?php echo esc_html( $fname ); ?></strong></td>
                        <td style="font-size:12px;">
                            <?php foreach ( $mapped as $wc_field => $csv_col ) :
                                $label = $wc_fields[ $wc_field ]['label'] ?? $wc_field;
                            ?>
                            <span style="display:inline-flex;align-items:center;gap:4px;background:#e8f5e9;border:1px solid #a5d6a7;padding:2px 7px;border-radius:12px;margin:2px;font-size:11px;">
                                <strong><?php echo esc_html( $label ); ?></strong>
                                <span style="color:#646970;">← <?php echo esc_html( $csv_col ); ?></span>
                            </span>
                            <?php endforeach; ?>
                        </td>
                        <td>
                            <button class="button button-small cipro-edit-mapping" data-file="<?php echo esc_attr( $fname ); ?>">✏ <?php esc_html_e( 'Edit', 'cip-pro' ); ?></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        <script>
        var ciproWcFields  = <?php echo wp_json_encode( $wc_fields ); ?>;
        var ciproFileMaps  = <?php echo wp_json_encode( $file_maps ); ?>;
        var ciproGlobalMap = <?php echo wp_json_encode( $global_map ); ?>;
        </script>
        <?php
    }

    // ─────────────────────────────────────────
    //  TAB: IMPORT
    // ─────────────────────────────────────────

    private function render_import_tab() {
        $files  = $this->file_manager->list_csv_files();
        $plugin = CSV_Importer_Pro_Woo::get_instance();
        ?>
        <div class="cipro-card">
            <h2>▶ <?php esc_html_e( 'Run Import', 'cip-pro' ); ?></h2>

            <?php if ( empty( $files ) ) : ?>
                <div class="notice notice-warning inline"><p><?php esc_html_e( 'Upload CSV files first.', 'cip-pro' ); ?></p></div>
            <?php else : ?>

            <!-- File selection -->
            <div style="margin-bottom:20px;">
                <label style="font-weight:600;display:block;margin-bottom:10px;">
                    <input type="checkbox" id="cipro-check-all" checked style="margin-right:6px;">
                    <?php esc_html_e( 'Select All', 'cip-pro' ); ?>
                </label>
                <?php foreach ( $files as $f ) : ?>
                <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:#f8f9fa;border:1px solid #e2e4e7;border-radius:6px;margin-bottom:8px;flex-wrap:wrap;gap:8px;">
                    <label style="display:flex;align-items:center;gap:10px;cursor:pointer;">
                        <input type="checkbox" class="cipro-file-check" value="<?php echo esc_attr( $f['name'] ); ?>" checked>
                        <strong><?php echo esc_html( $f['name'] ); ?></strong>
                        <span style="color:#646970;font-size:13px;"><?php echo esc_html( number_format( $f['rows'] ) ); ?> <?php esc_html_e( 'rows', 'cip-pro' ); ?></span>
                    </label>
                    <div id="cipro-file-progress-<?php echo esc_attr( sanitize_key( $f['name'] ) ); ?>" style="display:none;font-size:12px;color:#646970;"></div>
                </div>
                <?php endforeach; ?>
            </div>

            <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;">
                <button type="button" class="button button-primary button-large" id="cipro-run-import">
                    ▶ <?php esc_html_e( 'Start Import', 'cip-pro' ); ?>
                </button>
                <button type="button" class="button button-large" id="cipro-background-import" title="<?php esc_attr_e( 'Runs import in background — browser can be closed', 'cip-pro' ); ?>">
                    🚀 <?php esc_html_e( 'Background Import', 'cip-pro' ); ?>
                </button>
                <span style="font-size:12px;color:#646970;"><?php esc_html_e( 'Background mode runs via WP Cron — safe for very large files.', 'cip-pro' ); ?></span>
            </div>

            <div id="cipro-import-progress" style="display:none;margin-top:20px;"></div>
            <div id="cipro-import-result"   style="display:none;margin-top:20px;"></div>

            <?php endif; ?>
        </div>

        <!-- Next scheduled run info -->
        <div class="cipro-card" style="background:#f0f6fc;border-color:#2271b1;">
            <h3 style="margin:0 0 8px;font-size:14px;">⏰ <?php esc_html_e( 'Next Auto-Import', 'cip-pro' ); ?></h3>
            <p style="margin:0;color:#1d2327;">
                <strong><?php echo esc_html( $plugin->cron->get_schedule_label() ); ?></strong>
                — <?php echo esc_html( $plugin->cron->get_next_run() ); ?>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=csv-importer-pro-woo&tab=schedule' ) ); ?>" style="margin-left:12px;font-size:12px;"><?php esc_html_e( 'Change Schedule →', 'cip-pro' ); ?></a>
            </p>
        </div>
        <?php
    }

    // ─────────────────────────────────────────
    //  TAB: SCHEDULE (PRO FEATURE)
    // ─────────────────────────────────────────

    private function render_schedule_tab() {
        $plugin    = CSV_Importer_Pro_Woo::get_instance();
        $freq      = get_option( 'cipro_cron_schedule', 'daily' );
        $time      = get_option( 'cipro_cron_time', '02:00' );
        $next_run  = $plugin->cron->get_next_run();
        $schedules = [
            'hourly'     => __( 'Every Hour',   'cip-pro' ),
            'twicedaily' => __( 'Twice Daily',  'cip-pro' ),
            'daily'      => __( 'Once Daily',   'cip-pro' ),
            'weekly'     => __( 'Once Weekly',  'cip-pro' ),
            'monthly'    => __( 'Once Monthly', 'cip-pro' ),
        ];
        ?>
        <div class="cipro-card">
            <h2>⏰ <?php esc_html_e( 'Auto-Import Schedule', 'cip-pro' ); ?></h2>
            <p><?php esc_html_e( 'Set your import to run automatically. The plugin will process all uploaded CSV files at the configured time.', 'cip-pro' ); ?></p>

            <!-- Status box -->
            <div style="padding:16px 20px;background:#f0fdf4;border:1px solid #a5d6a7;border-radius:6px;margin-bottom:24px;display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
                <div>
                    <div style="font-size:13px;color:#646970;margin-bottom:4px;"><?php esc_html_e( 'Current Schedule', 'cip-pro' ); ?></div>
                    <strong style="font-size:16px;"><?php echo esc_html( $schedules[ $freq ] ?? $freq ); ?></strong>
                    <span style="color:#646970;margin-left:8px;font-size:13px;"><?php esc_html_e( 'at', 'cip-pro' ); ?> <strong><?php echo esc_html( $time ); ?></strong></span>
                </div>
                <div style="border-left:1px solid #a5d6a7;padding-left:16px;">
                    <div style="font-size:13px;color:#646970;margin-bottom:4px;"><?php esc_html_e( 'Next Run', 'cip-pro' ); ?></div>
                    <strong style="color:#00a32a;"><?php echo esc_html( $next_run ); ?></strong>
                </div>
            </div>

            <form method="post">
                <?php wp_nonce_field( 'cipro_schedule', 'cipro_schedule_nonce' ); ?>

                <table class="form-table" style="max-width:600px;">
                    <tr>
                        <th scope="row"><label for="cipro_frequency"><?php esc_html_e( 'Frequency', 'cip-pro' ); ?></label></th>
                        <td>
                            <select name="cipro_frequency" id="cipro_frequency" style="width:100%;max-width:260px;height:36px;">
                                <?php foreach ( $schedules as $val => $label ) : ?>
                                    <option value="<?php echo esc_attr( $val ); ?>" <?php selected( $freq, $val ); ?>><?php echo esc_html( $label ); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="cipro_time"><?php esc_html_e( 'Time of Day', 'cip-pro' ); ?></label></th>
                        <td>
                            <input type="time" name="cipro_time" id="cipro_time" value="<?php echo esc_attr( $time ); ?>" style="width:140px;height:36px;padding:0 8px;">
                            <p class="description" style="margin-top:6px;"><?php esc_html_e( 'Server time (UTC). Your server time is:', 'cip-pro' ); ?> <strong><?php echo esc_html( date( 'H:i', current_time( 'timestamp' ) ) ); ?></strong></p>
                        </td>
                    </tr>
                </table>

                <div style="margin-top:20px;display:flex;gap:12px;align-items:center;flex-wrap:wrap;">
                    <button type="submit" name="cipro_save_schedule" class="button button-primary button-large">
                        💾 <?php esc_html_e( 'Save Schedule', 'cip-pro' ); ?>
                    </button>
                    <button type="button" class="button button-large" id="cipro-run-now-bg">
                        🚀 <?php esc_html_e( 'Run Import Now (Background)', 'cip-pro' ); ?>
                    </button>
                    <span id="cipro-bg-status" style="display:none;color:#00a32a;font-weight:600;"></span>
                </div>
            </form>
        </div>

        <div class="cipro-card" style="background:#fffbf0;border-color:#f59e0b;">
            <h3 style="margin:0 0 8px;font-size:14px;">ℹ <?php esc_html_e( 'How Auto-Scheduling Works', 'cip-pro' ); ?></h3>
            <ol style="margin:0 0 0 20px;color:#646970;font-size:13px;line-height:2;">
                <li><?php esc_html_e( 'All CSV files in the upload folder are processed automatically.', 'cip-pro' ); ?></li>
                <li><?php esc_html_e( 'Products are created if new, or updated if SKU already exists.', 'cip-pro' ); ?></li>
                <li><?php esc_html_e( 'Import runs via WordPress Cron — no server-level cron needed.', 'cip-pro' ); ?></li>
                <li><?php esc_html_e( 'For best reliability on low-traffic sites, set up a server cron to trigger wp-cron.php.', 'cip-pro' ); ?></li>
                <li><?php esc_html_e( 'All activity is logged. Check the Logs tab after each run.', 'cip-pro' ); ?></li>
            </ol>
            <div style="margin-top:16px;padding:12px;background:#fff;border-radius:4px;font-size:12px;">
                <strong><?php esc_html_e( 'Optional: Server-level cron command', 'cip-pro' ); ?></strong>
                <code style="display:block;margin-top:6px;padding:8px;background:#f6f7f7;border-radius:4px;">*/15 * * * * wget -q -O /dev/null "<?php echo esc_url( site_url( 'wp-cron.php?doing_wp_cron' ) ); ?>"</code>
            </div>
        </div>
        <?php
    }

    // ─────────────────────────────────────────
    //  TAB: IMAGES
    // ─────────────────────────────────────────

    private function render_images_tab() {
        $stats = $this->file_manager->image_stats();
        ?>
        <div class="cipro-card">
            <h2>🖼 <?php esc_html_e( 'Product Images', 'cip-pro' ); ?></h2>
            <div style="padding:12px 16px;background:#f0f6fc;border-left:4px solid #2271b1;border-radius:4px;margin-bottom:20px;">
                🖼 <strong><?php echo esc_html( $stats['count'] ); ?></strong> <?php esc_html_e( 'images uploaded', 'cip-pro' ); ?> &nbsp;|&nbsp;
                💾 <strong><?php echo esc_html( $stats['size_mb'] ); ?> MB</strong>
            </div>
            <form method="post" enctype="multipart/form-data">
                <?php wp_nonce_field( 'cipro_upload_images', 'cipro_images_nonce' ); ?>
                <div class="cipro-form-row">
                    <label><strong><?php esc_html_e( 'Upload Images ZIP', 'cip-pro' ); ?></strong>
                        <p class="description"><?php esc_html_e( 'Name each image after its product SKU. e.g. SKU001.jpg, PROD-100.png', 'cip-pro' ); ?></p>
                        <input type="file" name="cipro_images_zip" accept=".zip" style="margin-top:8px;width:100%;max-width:520px;">
                    </label>
                </div>
                <button type="submit" name="cipro_upload_images" class="button button-primary">⬆ <?php esc_html_e( 'Upload ZIP', 'cip-pro' ); ?></button>
            </form>
        </div>
        <?php
    }

    // ─────────────────────────────────────────
    //  TAB: LOGS
    // ─────────────────────────────────────────

    private function render_logs_tab() {
        ?>
        <div class="cipro-card">
            <h2>📋 <?php esc_html_e( 'Import Logs', 'cip-pro' ); ?></h2>
            <button class="button" id="cipro-load-logs">👁 <?php esc_html_e( "Load Logs", 'cip-pro' ); ?></button>
            <div id="cipro-log-output" style="display:none;margin-top:16px;">
                <pre style="background:#1d2327;color:#7dc17e;padding:20px;border-radius:6px;max-height:500px;overflow:auto;font-size:12px;line-height:1.6;"></pre>
            </div>
        </div>
        <?php
    }

    // ─────────────────────────────────────────
    //  TAB: DANGER ZONE
    // ─────────────────────────────────────────

    private function render_danger_tab() {
        ?>
        <div class="cipro-card" style="border-color:#d63638;">
            <h2 style="color:#d63638;">⚠ <?php esc_html_e( 'Danger Zone', 'cip-pro' ); ?></h2>
            <p><?php esc_html_e( 'These actions are irreversible. Please make a backup before proceeding.', 'cip-pro' ); ?></p>

            <div style="padding:20px;background:#fdf2f2;border:1px solid #f5c2c2;border-radius:6px;">
                <h3 style="margin:0 0 8px;color:#d63638;">🗑 <?php esc_html_e( 'Delete All WooCommerce Products', 'cip-pro' ); ?></h3>
                <p style="margin:0 0 16px;color:#646970;"><?php esc_html_e( 'This will permanently delete ALL products from your WooCommerce store. This cannot be undone.', 'cip-pro' ); ?></p>
                <button type="button" class="button" id="cipro-delete-all"
                        style="background:#d63638;border-color:#b32d2e;color:#fff;font-weight:600;">
                    🗑 <?php esc_html_e( 'Delete All Products', 'cip-pro' ); ?>
                </button>
                <span id="cipro-delete-status" style="display:none;margin-left:12px;font-weight:600;"></span>
            </div>
        </div>
        <?php
    }

    // ─────────────────────────────────────────
    //  TAB: LICENSE
    // ─────────────────────────────────────────

    private function render_license_tab() {
        $key     = $this->license->get_key();
        $status  = $this->license->get_status();
        $expiry  = $this->license->get_expiry();
        $active  = $status === 'active';
        ?>
        <div class="cipro-card" style="max-width:600px;">
            <h2>🔑 <?php esc_html_e( 'License Activation', 'cip-pro' ); ?></h2>

            <!-- Status -->
            <div style="padding:14px 18px;border-radius:6px;margin-bottom:24px;background:<?php echo $active ? '#f0fdf4' : '#fdf2f2'; ?>;border:1px solid <?php echo $active ? '#a5d6a7' : '#f5c2c2'; ?>;">
                <div style="font-size:15px;font-weight:700;color:<?php echo $active ? '#00a32a' : '#d63638'; ?>;">
                    <?php echo $active ? '✅ ' . esc_html__( 'License Active', 'cip-pro' ) : '⚠ ' . esc_html__( 'License Inactive', 'cip-pro' ); ?>
                </div>
                <?php if ( $active && $expiry ) : ?>
                    <div style="font-size:13px;color:#646970;margin-top:4px;"><?php esc_html_e( 'Expires:', 'cip-pro' ); ?> <strong><?php echo esc_html( $expiry ); ?></strong></div>
                <?php endif; ?>
                <?php if ( $active && $key ) : ?>
                    <div style="font-size:12px;color:#646970;margin-top:4px;"><?php esc_html_e( 'Key:', 'cip-pro' ); ?> <code><?php echo esc_html( substr( $key, 0, 8 ) . str_repeat( '•', max( 0, strlen( $key ) - 8 ) ) ); ?></code></div>
                <?php endif; ?>
            </div>

            <!-- Input -->
            <div style="margin-bottom:20px;">
                <label for="cipro-license-key" style="font-weight:600;display:block;margin-bottom:8px;"><?php esc_html_e( 'Your License Key', 'cip-pro' ); ?></label>
                <input type="text" id="cipro-license-key" value="<?php echo esc_attr( $key ); ?>"
                       placeholder="XXXX-XXXX-XXXX-XXXX"
                       style="width:100%;max-width:440px;height:38px;padding:0 12px;font-family:monospace;font-size:14px;letter-spacing:1px;">
            </div>

            <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
                <?php if ( ! $active ) : ?>
                    <button type="button" class="button button-primary button-large" id="cipro-activate-license">
                        🔓 <?php esc_html_e( 'Activate License', 'cip-pro' ); ?>
                    </button>
                <?php else : ?>
                    <button type="button" class="button button-large" id="cipro-deactivate-license">
                        🔒 <?php esc_html_e( 'Deactivate License', 'cip-pro' ); ?>
                    </button>
                <?php endif; ?>
                <span id="cipro-license-msg" style="font-weight:600;display:none;"></span>
            </div>

            <div style="margin-top:28px;padding:14px;background:#f6f7f7;border-radius:6px;font-size:13px;color:#646970;line-height:1.8;">
                <strong><?php esc_html_e( 'Where to get a license key:', 'cip-pro' ); ?></strong><br>
                <?php esc_html_e( 'Purchase CSV Importer Pro from our website. Your key will be emailed to you after payment.', 'cip-pro' ); ?>
                <br><a href="https://your-website.com/csv-importer-pro" target="_blank" style="font-weight:600;"><?php esc_html_e( 'Buy License →', 'cip-pro' ); ?></a>
                <br><br>
                <strong><?php esc_html_e( 'Need help?', 'cip-pro' ); ?></strong>
                <?php esc_html_e( 'Contact support at', 'cip-pro' ); ?> <a href="mailto:support@your-website.com">support@your-website.com</a>
            </div>
        </div>
        <?php
    }

    // ─────────────────────────────────────────
    //  STYLES
    // ─────────────────────────────────────────

    private function render_styles() { ?>
        <style>
        .cipro-tabs { display:flex;gap:3px;margin:16px 0 0;border-bottom:2px solid #c3c4c7;flex-wrap:wrap; }
        .cipro-tab { padding:9px 15px;text-decoration:none;color:#1d2327;background:#f0f0f1;border:1px solid #c3c4c7;border-bottom:none;border-radius:4px 4px 0 0;font-size:13px;font-weight:500;white-space:nowrap; }
        .cipro-tab:hover { background:#fff;color:#2271b1; }
        .cipro-tab.active { background:#fff;color:#2271b1;border-bottom:2px solid #fff;margin-bottom:-2px; }
        .cipro-tab.cipro-tab-license { background:#fef3c7;color:#92400e;border-color:#fcd34d; }
        .cipro-tab-content { background:#fff;border:1px solid #c3c4c7;border-top:none;padding:24px;border-radius:0 0 4px 4px; }
        .cipro-card { background:#fff;border:1px solid #e2e4e7;border-radius:6px;padding:22px;margin-bottom:20px;box-shadow:0 1px 3px rgba(0,0,0,.04); }
        .cipro-card h2 { margin:0 0 14px;font-size:16px;border-bottom:1px solid #f0f0f1;padding-bottom:10px; }
        .cipro-form-row { margin-bottom:18px; }
        .cipro-form-row .description { color:#646970;font-size:12px;margin:3px 0 0;font-style:italic; }
        .cipro-table th { background:#f6f7f7;font-weight:600; }
        .cipro-table th, .cipro-table td { padding:10px 12px;vertical-align:middle; }
        /* Mapping */
        .cipro-step-box { display:flex;align-items:center;gap:14px;padding:16px 18px;background:#f8f9fa;border:1px solid #e2e4e7;border-radius:8px;margin-bottom:10px; }
        .cipro-step-num { width:30px;height:30px;border-radius:50%;background:#2271b1;color:#fff;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0; }
        .cipro-mapping-wrapper { border:1px solid #e2e4e7;border-radius:6px;overflow:hidden; }
        .cipro-map-section-title { padding:7px 14px;background:#f0f0f1;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#646970; }
        .cipro-map-row { display:grid;grid-template-columns:260px 36px 1fr;align-items:center;padding:10px 14px;border-bottom:1px solid #f0f0f1; }
        .cipro-map-row:last-child { border-bottom:none; }
        .cipro-map-row.required { background:#fffef5; }
        .cipro-map-row.mapped  { background:#f0fdf4!important; }
        .cipro-wc-field { display:flex;align-items:center;gap:8px; }
        .cipro-field-icon { font-size:16px;width:22px;text-align:center; }
        .cipro-req-badge { background:#d63638;color:#fff;font-size:10px;padding:1px 6px;border-radius:10px;margin-left:5px;font-weight:600; }
        .cipro-arrow { text-align:center;color:#2271b1;font-size:18px;font-weight:700; }
        .cipro-csv-col select { width:100%;max-width:320px;padding:5px 8px;height:34px;border:1px solid #8c8f94;border-radius:4px; }
        .cipro-csv-col select.is-mapped { border-color:#00a32a!important;background:#f0fdf4; }
        .cipro-col-preview { font-size:11px;color:#00a32a;font-weight:600;margin-top:3px; }
        .cipro-unmapped-tag { background:#f3f4f6;border:1px solid #d1d5db;padding:2px 9px;border-radius:12px;font-size:12px;color:#374151; }
        @media (max-width:860px) { .cipro-map-row { grid-template-columns:1fr; } .cipro-arrow { display:none; } }
        </style>
    <?php }

    // ─────────────────────────────────────────
    //  JAVASCRIPT
    // ─────────────────────────────────────────

    private function render_javascript( $active_tab ) { ?>
        <script>
        jQuery(document).ready(function($){
            var nonce = '<?php echo wp_create_nonce( 'cipro_ajax' ); ?>';

            // ── Delete CSV file ──
            $(document).on('click', '.cipro-delete-file', function(){
                var file = $(this).data('file');
                if (!confirm('Delete ' + file + '?')) return;
                $.post(ajaxurl, {action:'cipro_delete_csv_file', file:file, _ajax_nonce:nonce}, function(r){
                    r.success ? location.reload() : alert(r.data);
                });
            });

            // ══════════════════════════════════
            //  COLUMN MAPPING
            // ══════════════════════════════════
            var detectedCols = [];
            var fieldAliases = {
                'sku':               ['sku','item number','itemnumber','item_number','item code','product id','productid','part number','code','item#'],
                'name':              ['name','product name','productname','title','product title','item name'],
                'price':             ['price','sales price','salesprice','regular price','retail price','unit price','list price'],
                'sale_price':        ['sale price','sale_price','discount price','special price','promo price'],
                'description':       ['description','product description','long description','details','desc'],
                'short_description': ['short description','short_description','summary','brief','overview'],
                'stock':             ['stock','stock on hand','qty','quantity','inventory','units','available'],
                'category':          ['category','product category','cat','department','type'],
                'group':             ['group','product group','tag','brand','group id'],
                'weight':            ['weight','wt','mass','weight (kg)','weight (lb)'],
                'length':            ['length','len','depth'],
                'width':             ['width','wid'],
                'height':            ['height','ht'],
                'image_url':         ['image','image url','image_url','photo','picture','img','thumbnail'],
                'external_url':      ['url','link','external url','product url','website'],
            };

            $('#cipro-mapping-file').on('change', function(){
                $('#cipro-load-columns').prop('disabled', !$(this).val());
                if (!$(this).val()) $('#cipro-mapping-ui').hide();
            });

            $('#cipro-load-columns').on('click', function(){
                var file = $('#cipro-mapping-file').val();
                if (!file) return;
                $('#cipro-loading-cols').show();
                $(this).prop('disabled', true);

                $.post(ajaxurl, {action:'cipro_detect_columns', file:file, _ajax_nonce:nonce}, function(r){
                    $('#cipro-loading-cols').hide();
                    $('#cipro-load-columns').prop('disabled', false);
                    if (!r.success || !r.data.length) { alert('Could not detect columns.'); return; }

                    detectedCols = r.data;
                    var saved    = (ciproFileMaps[file]) ? ciproFileMaps[file] : ciproGlobalMap;
                    var reqOpts  = '<option value="">— Select CSV column —</option>';
                    var optOpts  = '<option value="">Do Not Import</option>';
                    $.each(detectedCols, function(i, c){ reqOpts += '<option value="'+esc(c)+'">'+esc(c)+'</option>'; optOpts += '<option value="'+esc(c)+'">'+esc(c)+'</option>'; });

                    $('.cipro-col-select').each(function(){
                        var field = $(this).data('field');
                        var isReq = $(this).closest('.cipro-map-row').hasClass('required');
                        $(this).html(isReq ? reqOpts : optOpts);
                        var sv = (saved && saved[field]) ? saved[field] : '';
                        if (sv && detectedCols.indexOf(sv) !== -1) {
                            $(this).val(sv);
                        } else {
                            var auto = smartMatch(field, detectedCols);
                            if (auto) $(this).val(auto);
                        }
                        updateRow($(this));
                    });
                    updateUnmapped();
                    $('#cipro-mapping-ui').slideDown(200);
                });
            });

            $(document).on('change', '.cipro-col-select', function(){ updateRow($(this)); updateUnmapped(); });

            function smartMatch(field, cols) {
                var al = fieldAliases[field] || [];
                var lo = cols.map(function(c){ return c.toLowerCase().trim(); });
                for (var i=0; i<al.length; i++){ var idx=lo.indexOf(al[i]); if(idx!==-1) return cols[idx]; }
                return null;
            }
            function updateRow($sel) {
                var $row = $sel.closest('.cipro-map-row');
                $row.find('.cipro-col-preview').hide().text('');
                if ($sel.val()) {
                    $sel.addClass('is-mapped'); $row.addClass('mapped');
                    $row.find('.cipro-col-preview').text('✅ ' + $sel.val()).show();
                } else {
                    $sel.removeClass('is-mapped'); $row.removeClass('mapped');
                }
            }
            function updateUnmapped() {
                var used = []; $('.cipro-col-select').each(function(){ if($(this).val()) used.push($(this).val()); });
                var un = detectedCols.filter(function(c){ return used.indexOf(c)===-1; });
                var $box = $('#cipro-unmapped-box'), $list = $('#cipro-unmapped-list');
                $list.empty();
                if (un.length) { $.each(un, function(i,c){ $list.append('<span class="cipro-unmapped-tag">'+esc(c)+'</span>'); }); $box.show(); }
                else { $box.hide(); }
            }

            $('#cipro-save-mapping').on('click', function(){
                var file = $('#cipro-mapping-file').val();
                var map  = {};
                $('.cipro-col-select').each(function(){ if($(this).val()) map[$(this).data('field')] = $(this).val(); });
                var missing = ['sku','name','price'].filter(function(f){ return !map[f]; });
                if (missing.length) { alert('Map required fields: ' + missing.join(', ')); return; }
                $(this).prop('disabled',true).text('Saving...');
                $.post(ajaxurl,{action:'cipro_save_mapping',file:file,mapping:map,_ajax_nonce:nonce},function(r){
                    $('#cipro-save-mapping').prop('disabled',false).html('💾 Save Mapping');
                    if (r.success) { $('#cipro-mapping-saved').show().delay(2500).fadeOut(); if(file) ciproFileMaps[file]=map; }
                    else alert(r.data);
                });
            });

            $(document).on('click', '.cipro-edit-mapping', function(){
                var file = $(this).data('file');
                $('#cipro-mapping-file').val(file).trigger('change');
                setTimeout(function(){ $('#cipro-load-columns').trigger('click'); }, 100);
                $('html,body').animate({scrollTop:0},400);
            });

            // ══════════════════════════════════
            //  RUN IMPORT
            // ══════════════════════════════════
            $('#cipro-check-all').on('change', function(){ $('.cipro-file-check').prop('checked', $(this).is(':checked')); });

            var importRunning = false;
            var importQueue   = [];
            var queueIdx      = 0;
            var grandTotals   = {created:0,updated:0,skipped:0,errors:0,processed:0};

            $('#cipro-run-import').on('click', function(){
                if (importRunning) { alert('Import already running!'); return; }
                importQueue = [];
                $('.cipro-file-check:checked').each(function(){ importQueue.push($(this).val()); });
                if (!importQueue.length) { alert('Select at least one file.'); return; }
                if (!confirm('Start import for ' + importQueue.length + ' file(s)?')) return;
                importRunning = true; queueIdx = 0;
                grandTotals   = {created:0,updated:0,skipped:0,errors:0,processed:0};
                $(this).prop('disabled',true);
                $('#cipro-import-result').hide();
                processNextFile();
            });

            function processNextFile() {
                if (queueIdx >= importQueue.length) {
                    importRunning = false;
                    $('#cipro-run-import').prop('disabled',false);
                    $('#cipro-import-progress').hide();
                    $('#cipro-import-result').show().html(
                        '<div style="padding:20px;background:#d4edda;border-left:4px solid #28a745;border-radius:6px;">' +
                        '<h3 style="margin:0 0 8px;color:#155724;">✅ All Files Imported!</h3>' +
                        '<p style="margin:0;">Total — Created: <strong>'+grandTotals.created+'</strong> | Updated: <strong>'+grandTotals.updated+'</strong> | Skipped: <strong>'+grandTotals.skipped+'</strong> | Errors: <strong>'+grandTotals.errors+'</strong></p>' +
                        '</div>'
                    );
                    return;
                }

                var file     = importQueue[queueIdx];
                var offset   = 0, batch = 1;
                var totals   = {created:0,updated:0,skipped:0,errors:0};
                var slug     = file.replace(/[^a-z0-9]/gi,'-');

                $('#cipro-import-progress').show().html(
                    '<div style="padding:16px;background:#f0f6fc;border-left:4px solid #2271b1;border-radius:6px;">' +
                    '<strong>📦 ' + esc(file) + '</strong> <span id="cipro-pct-'+slug+'">0%</span>' +
                    '<div style="background:#ddd;border-radius:4px;height:14px;margin:8px 0;"><div id="cipro-pbar-'+slug+'" style="background:#2271b1;height:100%;border-radius:4px;width:0%;transition:width .3s;"></div></div>' +
                    '<span id="cipro-ptext-'+slug+'">Starting...</span></div>'
                );

                function runBatch() {
                    $.ajax({url:ajaxurl,type:'POST',timeout:180000,
                        data:{action:'cipro_manual_import',file:file,batch:batch,offset:offset,_ajax_nonce:nonce},
                        success:function(r){
                            if (!r.success){ showFileErr(file, r.data||'Error'); return; }
                            var d=r.data;
                            totals.created+=d.created||0; totals.updated+=d.updated||0; totals.skipped+=d.skipped||0; totals.errors+=d.errors||0;
                            grandTotals.created+=d.created||0; grandTotals.updated+=d.updated||0; grandTotals.skipped+=d.skipped||0; grandTotals.errors+=d.errors||0;
                            var pct = d.total_rows>0 ? Math.min(100,Math.round(d.processed/d.total_rows*100)) : 100;
                            $('#cipro-pbar-'+slug).css('width',pct+'%');
                            $('#cipro-pct-'+slug).text(pct+'%');
                            $('#cipro-ptext-'+slug).text('Processed: '+d.processed+'/'+(d.total_rows||'?')+' · Created: '+totals.created+' Updated: '+totals.updated);
                            if (d.has_more){ batch++; offset=d.offset; setTimeout(runBatch,600); }
                            else { queueIdx++; setTimeout(processNextFile, 800); }
                        },
                        error:function(x,s,e){ showFileErr(file,s+': '+e); }
                    });
                }
                function showFileErr(fname, msg){ importRunning=false; $('#cipro-run-import').prop('disabled',false); $('#cipro-import-result').show().html('<div style="padding:18px;background:#f8d7da;border-left:4px solid #d63638;border-radius:6px;"><h3 style="color:#721c24;">❌ Error in '+esc(fname)+'</h3><p>'+msg+'</p></div>'); }
                runBatch();
            }

            // Background import
            $('#cipro-background-import,#cipro-run-now-bg').on('click', function(){
                var $btn = $(this);
                if (!confirm('This will schedule all CSVs to run in the background via WP Cron. Continue?')) return;
                $btn.prop('disabled',true);
                $.post(ajaxurl,{action:'cipro_background_import',_ajax_nonce:nonce},function(r){
                    $btn.prop('disabled',false);
                    if (r.success) {
                        $('#cipro-bg-status').text('✅ '+r.data).show().delay(4000).fadeOut();
                        alert('✅ Background import scheduled! Check Logs tab in a few minutes.');
                    } else { alert('Error: '+r.data); }
                });
            });

            // Delete all products
            $('#cipro-delete-all').on('click', function(){
                if (!confirm('⚠️ Delete ALL products? This CANNOT be undone!')) return;
                if (!confirm('Are you absolutely sure?')) return;
                $(this).prop('disabled',true).text('Deleting...');
                $.post(ajaxurl,{action:'cipro_delete_all',_ajax_nonce:nonce},function(r){
                    $('#cipro-delete-all').prop('disabled',false).text('🗑 Delete All Products');
                    if (r.success) { $('#cipro-delete-status').css('color','#00a32a').text('✅ Deleted: '+r.data+' products').show(); }
                    else { $('#cipro-delete-status').css('color','#d63638').text('❌ '+r.data).show(); }
                });
            });

            // Logs
            $('#cipro-load-logs').on('click', function(){
                var $out = $('#cipro-log-output');
                if ($out.is(':visible')){ $out.hide(); $(this).text("👁 Load Logs"); return; }
                $(this).text('Loading...');
                $.post(ajaxurl,{action:'cipro_view_logs',_ajax_nonce:nonce},function(r){
                    if(r.success){ $out.find('pre').text(r.data); $out.show(); $('#cipro-load-logs').text('Hide Logs'); }
                });
            });

            // ── License ──
            $('#cipro-activate-license').on('click', function(){
                var key = $('#cipro-license-key').val().trim();
                if (!key) { alert('Enter your license key.'); return; }
                $(this).prop('disabled',true).text('Activating...');
                $.post(ajaxurl,{action:'cipro_activate_license',license_key:key,_ajax_nonce:nonce},function(r){
                    $('#cipro-activate-license').prop('disabled',false).text('🔓 Activate License');
                    var $msg = $('#cipro-license-msg').show();
                    if (r.success) { $msg.css('color','#00a32a').text(r.message); setTimeout(function(){ location.reload(); },1200); }
                    else { $msg.css('color','#d63638').text(r.message || 'Activation failed.'); }
                });
            });

            $('#cipro-deactivate-license').on('click', function(){
                if (!confirm('Deactivate license on this site?')) return;
                $(this).prop('disabled',true);
                $.post(ajaxurl,{action:'cipro_deactivate_license',_ajax_nonce:nonce},function(r){
                    setTimeout(function(){ location.reload(); },800);
                });
            });

            function esc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
        });
        </script>
    <?php }
}
