<?php
/**
 * CIPRO_License — License key management for Pro version.
 *
 * How it works:
 * 1. User enters their license key in Settings tab.
 * 2. Plugin sends key to YOUR license server (EDD, WooCommerce, or custom API).
 * 3. Server validates and returns active/inactive status.
 * 4. Status cached in DB for 24 hours.
 *
 * TO SET UP YOUR LICENSE SERVER:
 * - Option A: Use Easy Digital Downloads (EDD) Software Licensing add-on.
 * - Option B: Use WooCommerce + WooCommerce Software Add-on.
 * - Option C: Use a custom endpoint (see validate_with_server() below).
 * Set CIP_PRO_LICENSE_SERVER_URL to your store URL below.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ── CONFIGURE THIS ──
// Replace with your actual store/licensing server URL
if ( ! defined( 'CIP_PRO_LICENSE_SERVER_URL' ) ) {
    define( 'CIP_PRO_LICENSE_SERVER_URL', 'https://your-website.com' );
}
if ( ! defined( 'CIP_PRO_ITEM_ID' ) ) {
    define( 'CIP_PRO_ITEM_ID', 1 ); // Your EDD product/post ID
}
if ( ! defined( 'CIP_PRO_ITEM_NAME' ) ) {
    define( 'CIP_PRO_ITEM_NAME', 'CSV Importer Pro for WooCommerce' );
}

class CIPRO_License {

    const OPTION_KEY      = 'cipro_license_key';
    const STATUS_KEY      = 'cipro_license_status';
    const EXPIRY_KEY      = 'cipro_license_expiry';
    const LAST_CHECK_KEY  = 'cipro_license_last_check';
    const CACHE_HOURS     = 24;

    /**
     * Is the license currently active?
     */
    public function is_active() {
        $status = get_option( self::STATUS_KEY, 'inactive' );

        // Re-check server every 24 hours (Bypass remote check for demo key)
        $last_check = (int) get_option( self::LAST_CHECK_KEY, 0 );
        if ( $status === 'active' && ( time() - $last_check ) > ( self::CACHE_HOURS * 3600 ) ) {
            $key = $this->get_key();
            if ( $key && $key !== 'DEMO-PRO-TEST-2026' ) {
                $this->check_with_server( $key );
                $status = get_option( self::STATUS_KEY, 'inactive' );
            }
        }

        return $status === 'active';
    }

    /**
     * Get the stored license key
     */
    public function get_key() {
        return get_option( self::OPTION_KEY, '' );
    }

    /**
     * Get license status string
     */
    public function get_status() {
        return get_option( self::STATUS_KEY, 'inactive' );
    }

    /**
     * Get license expiry date
     */
    public function get_expiry() {
        return get_option( self::EXPIRY_KEY, '' );
    }

    /**
     * Activate a license key
     * Sends request to your licensing server, stores result.
     *
     * @param  string $key  License key entered by user
     * @return array        [ 'success' => bool, 'message' => string ]
     */
    public function activate( $key ) {
        $key = sanitize_text_field( trim( $key ) );

        if ( empty( $key ) ) {
            return [ 'success' => false, 'message' => __( 'Please enter a license key.', 'cip-pro' ) ];
        }

        // Save the key first
        update_option( self::OPTION_KEY, $key );

        /**
         * Demo & Client Testing Environment Key Support
         * Allows testing and previewing all Pro features without contacting a live licensing server.
         */
        if ( strtoupper( $key ) === 'DEMO-PRO-TEST-2026' ) {
            update_option( self::STATUS_KEY,     'active' );
            update_option( self::EXPIRY_KEY,     '2026-12-31' );
            update_option( self::LAST_CHECK_KEY, time() );
            return [ 'success' => true, 'message' => __( '✅ License activated successfully (Demo / Preview Mode)!', 'cip-pro' ) ];
        }

        // Contact live licensing server
        $result = $this->validate_with_server( $key, 'activate_license' );

        if ( $result['success'] ) {
            update_option( self::STATUS_KEY,     'active' );
            update_option( self::EXPIRY_KEY,     $result['expires'] ?? '' );
            update_option( self::LAST_CHECK_KEY, time() );
            return [ 'success' => true, 'message' => __( '✅ License activated successfully!', 'cip-pro' ) ];
        } else {
            update_option( self::STATUS_KEY, 'inactive' );
            return [ 'success' => false, 'message' => $result['error'] ?? __( 'Activation failed. Please check your key.', 'cip-pro' ) ];
        }
    }

    /**
     * Deactivate a license key (frees up a site activation on your server)
     */
    public function deactivate() {
        $key = $this->get_key();

        if ( $key ) {
            $this->validate_with_server( $key, 'deactivate_license' );
        }

        update_option( self::STATUS_KEY, 'inactive' );
        update_option( self::LAST_CHECK_KEY, 0 );

        return [ 'success' => true, 'message' => __( 'License deactivated.', 'cip-pro' ) ];
    }

    /**
     * Check license status silently (background re-validation)
     */
    private function check_with_server( $key ) {
        $result = $this->validate_with_server( $key, 'check_license' );

        if ( isset( $result['license'] ) ) {
            update_option( self::STATUS_KEY, $result['license'] === 'valid' ? 'active' : 'inactive' );
            update_option( self::LAST_CHECK_KEY, time() );
        }
    }

    /**
     * Contact your EDD licensing server
     *
     * @param  string $key     License key
     * @param  string $action  EDD action: activate_license | deactivate_license | check_license
     * @return array
     */
    private function validate_with_server( $key, $action ) {
        $api_params = [
            'edd_action' => $action,
            'license'    => $key,
            'item_id'    => CIP_PRO_ITEM_ID,
            'item_name'  => rawurlencode( CIP_PRO_ITEM_NAME ),
            'url'        => home_url(),
        ];

        $response = wp_remote_post(
            esc_url_raw( add_query_arg( $api_params, CIP_PRO_LICENSE_SERVER_URL ) ),
            [
                'timeout'   => 15,
                'sslverify' => true,
            ]
        );

        // If request failed
        if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
            return [
                'success' => false,
                'error'   => __( 'Could not connect to license server. Please try again.', 'cip-pro' ),
            ];
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( ! is_array( $body ) ) {
            return [ 'success' => false, 'error' => __( 'Invalid server response.', 'cip-pro' ) ];
        }

        // EDD response: $body['license'] = 'valid' | 'invalid' | 'expired' | 'disabled'
        if ( isset( $body['license'] ) && $body['license'] === 'valid' ) {
            return [
                'success' => true,
                'license' => 'valid',
                'expires' => $body['expires'] ?? '',
            ];
        }

        // Map EDD error messages
        $errors = [
            'expired'            => __( 'Your license has expired. Please renew.', 'cip-pro' ),
            'revoked'            => __( 'License has been disabled. Contact support.', 'cip-pro' ),
            'missing'            => __( 'License key not found.', 'cip-pro' ),
            'invalid'            => __( 'License key is invalid.', 'cip-pro' ),
            'site_inactive'      => __( 'License not active for this site.', 'cip-pro' ),
            'item_name_mismatch' => __( 'License is for a different product.', 'cip-pro' ),
            'no_activations_left'=> __( 'Maximum site activations reached.', 'cip-pro' ),
        ];

        $status  = $body['license'] ?? 'invalid';
        $message = $errors[ $status ] ?? __( 'License is not valid.', 'cip-pro' );

        return [ 'success' => false, 'license' => $status, 'error' => $message ];
    }
}
