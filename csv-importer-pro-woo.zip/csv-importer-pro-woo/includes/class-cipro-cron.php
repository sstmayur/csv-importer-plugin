<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * CIPRO_Cron — Auto-scheduling for Pro version
 * Supports: hourly, twicedaily, daily, weekly
 */
class CIPRO_Cron {

    private $logger;

    public function __construct( $logger ) {
        $this->logger = $logger;
    }

    public function register_hooks() {
        add_filter( 'cron_schedules', [ $this, 'add_schedules' ] );

        if ( ! wp_next_scheduled( 'cipro_scheduled_import' ) ) {
            $this->schedule();
        }
    }

    public function add_schedules( $schedules ) {
        if ( ! isset( $schedules['weekly'] ) ) {
            $schedules['weekly'] = [
                'interval' => WEEK_IN_SECONDS,
                'display'  => __( 'Once Weekly', 'cip-pro' ),
            ];
        }
        if ( ! isset( $schedules['monthly'] ) ) {
            $schedules['monthly'] = [
                'interval' => MONTH_IN_SECONDS,
                'display'  => __( 'Once Monthly', 'cip-pro' ),
            ];
        }
        return $schedules;
    }

    public function schedule() {
        $freq     = get_option( 'cipro_cron_schedule', 'daily' );
        $time_str = get_option( 'cipro_cron_time', '02:00' );

        $next = strtotime( 'today ' . $time_str );
        if ( $next < time() ) {
            $next = strtotime( 'tomorrow ' . $time_str );
        }

        wp_schedule_event( $next, $freq, 'cipro_scheduled_import' );
        $this->logger->info( "Auto-import scheduled: {$freq} at {$time_str}" );
    }

    public function reschedule() {
        wp_clear_scheduled_hook( 'cipro_scheduled_import' );
        $this->schedule();
    }

    /**
     * Schedule a one-time background import to run in 5 seconds
     */
    public function trigger_background_now() {
        $ts = wp_next_scheduled( 'cipro_background_import' );
        if ( $ts ) {
            wp_unschedule_event( $ts, 'cipro_background_import' );
        }

        wp_schedule_single_event( time() + 5, 'cipro_background_import' );
        spawn_cron();

        // Also trigger via HTTP (helps on hosts where wp-cron is slow)
        wp_remote_post(
            esc_url_raw( site_url( 'wp-cron.php?doing_wp_cron' ) ),
            [ 'timeout' => 0.01, 'blocking' => false, 'sslverify' => false ]
        );

        $this->logger->info( 'Background import queued (fires in 5 seconds)' );
    }

    public function deactivate() {
        wp_clear_scheduled_hook( 'cipro_scheduled_import' );
        wp_clear_scheduled_hook( 'cipro_background_import' );
        $this->logger->info( 'Cron hooks deactivated' );
    }

    /**
     * Get human-readable next scheduled run time
     */
    public function get_next_run() {
        $ts = wp_next_scheduled( 'cipro_scheduled_import' );
        if ( ! $ts ) return __( 'Not scheduled', 'cip-pro' );

        $diff = $ts - time();
        if ( $diff < 3600 ) {
            return sprintf( __( 'In %d minutes', 'cip-pro' ), round( $diff / 60 ) );
        } elseif ( $diff < 86400 ) {
            return sprintf( __( 'In %d hours', 'cip-pro' ), round( $diff / 3600 ) );
        }
        return date_i18n( 'M j, Y \a\t H:i', $ts );
    }

    public function get_schedule_label() {
        $map = [
            'hourly'     => __( 'Every Hour', 'cip-pro' ),
            'twicedaily' => __( 'Twice Daily', 'cip-pro' ),
            'daily'      => __( 'Daily', 'cip-pro' ),
            'weekly'     => __( 'Weekly', 'cip-pro' ),
            'monthly'    => __( 'Monthly', 'cip-pro' ),
        ];
        $freq = get_option( 'cipro_cron_schedule', 'daily' );
        return $map[ $freq ] ?? $freq;
    }
}
