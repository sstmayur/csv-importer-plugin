<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class CIPRO_Logger {

    private $log_dir;
    private $log_file;

    public function __construct( $log_dir ) {
        $this->log_dir  = $log_dir;
        if ( ! file_exists( $log_dir ) ) {
            wp_mkdir_p( $log_dir );
        }
        $this->log_file = $log_dir . 'import-' . date( 'Y-m-d' ) . '.log';
    }

    public function info( $msg )    { $this->log( 'INFO',    $msg ); }
    public function warning( $msg ) { $this->log( 'WARNING', $msg ); }
    public function error( $msg )   { $this->log( 'ERROR',   $msg ); }

    private function log( $level, $msg ) {
        $entry = '[' . date( 'Y-m-d H:i:s' ) . '] [' . $level . '] ' . $msg . "\n";
        file_put_contents( $this->log_file, $entry, FILE_APPEND | LOCK_EX );
        if ( $level === 'ERROR' ) {
            error_log( 'CSV Importer Pro: ' . $msg );
        }
    }

    public function get_recent_logs( $lines = 200 ) {
        if ( ! file_exists( $this->log_file ) ) {
            return 'No logs found for today.';
        }
        $all    = explode( "\n", file_get_contents( $this->log_file ) );
        $recent = array_slice( $all, -$lines );
        return implode( "\n", $recent );
    }

    public function get_log_files() {
        $files = glob( $this->log_dir . 'import-*.log' );
        if ( ! $files ) return [];
        rsort( $files );
        return array_slice( $files, 0, 7 ); // last 7 days
    }
}
