<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) exit;
$options = ['cipro_column_mapping','cipro_file_mappings','cipro_cron_schedule','cipro_cron_time',
            'cipro_license_key','cipro_license_status','cipro_license_expiry','cipro_license_last_check'];
foreach ( $options as $opt ) { delete_option( $opt ); }
delete_transient( 'cipro_import_running' );
