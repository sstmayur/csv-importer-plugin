<?php
/**
 * Plugin Name: CSV Importer for WooCommerce
 * Plugin URI: https://your-website.com/csv-importer
 * Description: Easily import WooCommerce products from CSV files with smart column mapping and batch processing. Upgrade to Pro for auto-scheduling, multiple files, and more.
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://your-website.com
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: csv-importer-woo
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'CIWOO_VERSION',      '1.0.0' );
define( 'CIWOO_DIR',          plugin_dir_path( __FILE__ ) );
define( 'CIWOO_URL',          plugin_dir_url( __FILE__ ) );
define( 'CIWOO_BATCH_SIZE',   20 );   // Free: 20 products per batch
define( 'CIWOO_CSV_FOLDER',   'ciwoo-csv-files/' );
define( 'CIWOO_IMAGE_FOLDER', 'ciwoo-product-images/' );
define( 'CIWOO_LOG_FOLDER',   'ciwoo-import-logs/' );
define( 'CIWOO_MAX_FILES',    1 );    // Free: only 1 CSV file at a time

require_once CIWOO_DIR . 'includes/class-ciwoo-logger.php';
require_once CIWOO_DIR . 'includes/class-ciwoo-file-manager.php';
require_once CIWOO_DIR . 'includes/class-ciwoo-csv-parser.php';
require_once CIWOO_DIR . 'includes/class-ciwoo-product.php';
require_once CIWOO_DIR . 'includes/class-ciwoo-ajax.php';
require_once CIWOO_DIR . 'includes/class-ciwoo-admin.php';

class CSV_Importer_Woo_Free {

    public $logger;
    public $file_manager;
    public $parser;
    public $product;
    public $ajax;
    public $admin;

    private $upload_dir;

    public function __construct() {
        $this->upload_dir = wp_upload_dir();

        $this->logger       = new CIWOO_Logger( $this->get_path( 'log' ) );
        $this->file_manager = new CIWOO_File_Manager( $this->logger );
        $this->parser       = new CIWOO_CSV_Parser( $this->logger );
        $this->product      = new CIWOO_Product( $this->logger, $this->get_path( 'image' ) );
        $this->ajax         = new CIWOO_Ajax( $this->logger, $this->parser, $this->product, $this->file_manager );
        $this->admin        = new CIWOO_Admin( $this->logger, $this->file_manager );

        add_action( 'init', [ $this, 'init' ] );
        register_activation_hook( __FILE__, [ $this, 'activate' ] );
        register_deactivation_hook( __FILE__, [ $this, 'deactivate' ] );
    }

    public function get_path( $type ) {
        $base = trailingslashit( $this->upload_dir['basedir'] );
        switch ( $type ) {
            case 'csv':   return $base . CIWOO_CSV_FOLDER;
            case 'image': return $base . CIWOO_IMAGE_FOLDER;
            case 'log':   return $base . CIWOO_LOG_FOLDER;
            default:      return $base;
        }
    }

    public function init() {
        foreach ( [ 'csv', 'image', 'log' ] as $f ) {
            wp_mkdir_p( $this->get_path( $f ) );
        }

        add_action( 'admin_menu', [ $this->admin, 'add_admin_menu' ] );

        add_action( 'wp_ajax_ciwoo_manual_import',   [ $this->ajax, 'handle_manual_import' ] );
        add_action( 'wp_ajax_ciwoo_view_logs',       [ $this->ajax, 'handle_view_logs' ] );
        add_action( 'wp_ajax_ciwoo_delete_csv_file', [ $this->ajax, 'handle_delete_csv_file' ] );
        add_action( 'wp_ajax_ciwoo_save_mapping',    [ $this->ajax, 'handle_save_mapping' ] );
        add_action( 'wp_ajax_ciwoo_detect_columns',  [ $this->ajax, 'handle_detect_columns' ] );
        add_action( 'wp_ajax_ciwoo_download_file',   [ $this->ajax, 'handle_download_file' ] );
    }

    public function activate() {
        foreach ( [ 'csv', 'image', 'log' ] as $f ) {
            wp_mkdir_p( $this->get_path( $f ) );
        }
        if ( ! get_option( 'ciwoo_column_mapping' ) ) {
            update_option( 'ciwoo_column_mapping', [
                'sku'   => 'SKU',
                'name'  => 'Name',
                'price' => 'Price',
            ] );
        }
    }

    public function deactivate() {}

    /**
     * Run import — FREE version: only 1 file, max 500 rows limit shown as notice
     */
    public function run_import( $file_path ) {
        $stats    = [ 'processed' => 0, 'created' => 0, 'updated' => 0, 'skipped' => 0, 'errors' => 0 ];
        $filename = basename( $file_path );

        if ( ! file_exists( $file_path ) ) {
            $this->logger->error( "File not found: {$file_path}" );
            return $stats;
        }

        $mapping = $this->parser->get_mapping_for_file( $filename );
        $rows    = $this->parser->read_csv( $file_path, $mapping );

        if ( $rows === false ) {
            $this->logger->error( "[{$filename}] Failed to parse CSV" );
            return $stats;
        }

        $this->logger->info( "[{$filename}] " . count( $rows ) . " rows found" );
        $processed_skus = [];

        foreach ( $rows as $i => $row ) {
            try {
                $sku  = sanitize_text_field( trim( $row['sku']  ?? '' ) );
                $name = sanitize_text_field( trim( $row['name'] ?? '' ) );

                if ( empty( $sku ) || strlen( $sku ) < 2 )                                                   { $stats['skipped']++; continue; }
                if ( empty( $name ) )                                                                          { $stats['skipped']++; continue; }
                if ( ! isset( $row['price'] ) || ! is_numeric( $row['price'] ) || floatval( $row['price'] ) < 0 ) { $stats['skipped']++; continue; }
                if ( in_array( $sku, $processed_skus ) )                                                      { $stats['skipped']++; continue; }

                $processed_skus[] = $sku;

                $existing_id = wc_get_product_id_by_sku( $sku );
                if ( ! $existing_id ) {
                    global $wpdb;
                    $existing_id = $wpdb->get_var( $wpdb->prepare(
                        "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_sku' AND meta_value=%s LIMIT 1", $sku
                    ) );
                }

                if ( $existing_id ) {
                    $r = $this->product->update_product( $existing_id, $row );
                    $r ? $stats['updated']++ : $stats['skipped']++;
                } else {
                    $r = $this->product->create_product( $row );
                    $r ? $stats['created']++ : $stats['errors']++;
                }

                $stats['processed']++;

                if ( $stats['processed'] % CIWOO_BATCH_SIZE === 0 ) {
                    wp_cache_flush();
                }

            } catch ( \Throwable $e ) {
                $this->logger->error( "Row {$i}: " . $e->getMessage() );
                $stats['errors']++;
            }
        }

        $this->logger->info( "Done — P:{$stats['processed']} C:{$stats['created']} U:{$stats['updated']} S:{$stats['skipped']} E:{$stats['errors']}" );
        return $stats;
    }
}

// Init
global $csv_importer_woo_free;
$csv_importer_woo_free = new CSV_Importer_Woo_Free();
