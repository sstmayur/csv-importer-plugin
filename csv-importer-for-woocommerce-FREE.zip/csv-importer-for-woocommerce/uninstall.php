<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) exit;

$options = [
    'ciwoo_column_mapping',
    'ciwoo_file_mappings',
];
foreach ( $options as $opt ) {
    delete_option( $opt );
}
delete_transient( 'ciwoo_import_running' );
