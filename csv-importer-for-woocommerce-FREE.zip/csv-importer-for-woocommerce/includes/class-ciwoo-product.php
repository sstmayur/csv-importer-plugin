<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class CIWOO_Product {

    private $logger;
    private $image_folder;

    public function __construct( $logger, $image_folder ) {
        $this->logger       = $logger;
        $this->image_folder = trailingslashit( $image_folder );
    }

    /**
     * Create a new WooCommerce product
     */
    public function create_product( $data ) {
        try {
            $product_id = wp_insert_post( [
                'post_title'   => sanitize_text_field( $data['name'] ),
                'post_content' => isset( $data['description'] ) ? wp_kses_post( $data['description'] ) : '',
                'post_excerpt' => isset( $data['short_description'] ) ? wp_kses_post( $data['short_description'] ) : '',
                'post_type'    => 'product',
                'post_status'  => 'publish',
            ] );

            if ( ! $product_id || is_wp_error( $product_id ) ) {
                $this->logger->error( "Failed to create: " . esc_html( $data['name'] ) );
                return false;
            }

            wp_set_object_terms( $product_id, 'simple', 'product_type' );

            update_post_meta( $product_id, '_sku', sanitize_text_field( $data['sku'] ) );

            if ( isset( $data['price'] ) && is_numeric( $data['price'] ) ) {
                $price = floatval( $data['price'] );
                update_post_meta( $product_id, '_price',         $price );
                update_post_meta( $product_id, '_regular_price', $price );
            }

            if ( isset( $data['sale_price'] ) && is_numeric( $data['sale_price'] ) ) {
                update_post_meta( $product_id, '_sale_price', floatval( $data['sale_price'] ) );
                update_post_meta( $product_id, '_price',      floatval( $data['sale_price'] ) ); // sale price takes priority
            }

            if ( isset( $data['stock'] ) ) {
                $stock = intval( $data['stock'] );
                update_post_meta( $product_id, '_stock',        $stock );
                update_post_meta( $product_id, '_stock_status', $stock > 0 ? 'instock' : 'outofstock' );
                update_post_meta( $product_id, '_manage_stock', 'yes' );
            }

            if ( isset( $data['weight'] ) && is_numeric( $data['weight'] ) ) {
                update_post_meta( $product_id, '_weight', floatval( $data['weight'] ) );
            }
            if ( isset( $data['length'] ) && is_numeric( $data['length'] ) ) {
                update_post_meta( $product_id, '_length', floatval( $data['length'] ) );
            }
            if ( isset( $data['width'] ) && is_numeric( $data['width'] ) ) {
                update_post_meta( $product_id, '_width', floatval( $data['width'] ) );
            }
            if ( isset( $data['height'] ) && is_numeric( $data['height'] ) ) {
                update_post_meta( $product_id, '_height', floatval( $data['height'] ) );
            }

            if ( ! empty( $data['external_url'] ) ) {
                update_post_meta( $product_id, '_product_url', esc_url_raw( $data['external_url'] ) );
                wp_set_object_terms( $product_id, 'external', 'product_type' );
            }

            if ( ! empty( $data['category'] ) ) {
                $this->assign_category( $product_id, $data['category'] );
            }

            if ( ! empty( $data['group'] ) ) {
                $this->assign_tag( $product_id, $data['group'] );
            }

            // Image: URL from CSV or local file by SKU
            if ( ! empty( $data['image_url'] ) ) {
                $this->attach_image_from_url( $product_id, $data['image_url'] );
            } else {
                $this->attach_image( $product_id, $data['sku'] );
            }

            return $product_id;

        } catch ( \Throwable $e ) {
            $this->logger->error( "Create error: " . $e->getMessage() );
            return false;
        }
    }

    /**
     * Update existing WooCommerce product
     */
    public function update_product( $product_id, $data ) {
        try {
            $product = wc_get_product( $product_id );
            if ( ! $product ) return false;

            $needs_update = false;
            $name  = sanitize_text_field( $data['name'] );
            $desc  = isset( $data['description'] ) ? wp_kses_post( $data['description'] ) : '';
            $short = isset( $data['short_description'] ) ? wp_kses_post( $data['short_description'] ) : '';
            $price = isset( $data['price'] ) ? floatval( $data['price'] ) : null;
            $stock = isset( $data['stock'] ) ? intval( $data['stock'] ) : null;

            if ( $product->get_name() !== $name )                                              $needs_update = true;
            if ( $desc  && $product->get_description()       !== $desc  )                      $needs_update = true;
            if ( $short && $product->get_short_description() !== $short )                      $needs_update = true;
            if ( $price !== null && abs( (float) $product->get_regular_price() - $price ) > 0.001 ) $needs_update = true;
            if ( $stock !== null && (int) $product->get_stock_quantity() !== $stock )          $needs_update = true;

            if ( ! $needs_update ) return false;

            wp_update_post( [ 'ID' => $product_id, 'post_title' => $name, 'post_content' => $desc, 'post_excerpt' => $short ] );

            if ( $price !== null ) {
                update_post_meta( $product_id, '_price',         $price );
                update_post_meta( $product_id, '_regular_price', $price );
            }

            if ( isset( $data['sale_price'] ) && is_numeric( $data['sale_price'] ) ) {
                update_post_meta( $product_id, '_sale_price', floatval( $data['sale_price'] ) );
                update_post_meta( $product_id, '_price',      floatval( $data['sale_price'] ) );
            }

            if ( $stock !== null ) {
                update_post_meta( $product_id, '_stock',        $stock );
                update_post_meta( $product_id, '_stock_status', $stock > 0 ? 'instock' : 'outofstock' );
            }

            if ( isset( $data['weight'] ) && is_numeric( $data['weight'] ) ) update_post_meta( $product_id, '_weight', floatval( $data['weight'] ) );
            if ( isset( $data['length'] ) && is_numeric( $data['length'] ) ) update_post_meta( $product_id, '_length', floatval( $data['length'] ) );
            if ( isset( $data['width']  ) && is_numeric( $data['width']  ) ) update_post_meta( $product_id, '_width',  floatval( $data['width']  ) );
            if ( isset( $data['height'] ) && is_numeric( $data['height'] ) ) update_post_meta( $product_id, '_height', floatval( $data['height'] ) );

            if ( ! empty( $data['category'] ) ) $this->assign_category( $product_id, $data['category'] );
            if ( ! empty( $data['group'] ) )    $this->assign_tag( $product_id, $data['group'] );

            if ( ! has_post_thumbnail( $product_id ) ) {
                if ( ! empty( $data['image_url'] ) ) {
                    $this->attach_image_from_url( $product_id, $data['image_url'] );
                } else {
                    $this->attach_image( $product_id, $data['sku'] );
                }
            }

            return true;

        } catch ( \Throwable $e ) {
            $this->logger->error( "Update error #{$product_id}: " . $e->getMessage() );
            return false;
        }
    }

    /**
     * Attach product image from a URL (downloads to media library)
     */
    private function attach_image_from_url( $product_id, $url ) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $tmp = download_url( esc_url_raw( $url ) );
        if ( is_wp_error( $tmp ) ) {
            $this->logger->warning( "Image URL download failed: " . $url );
            return;
        }

        $filename = basename( parse_url( $url, PHP_URL_PATH ) );
        if ( empty( $filename ) ) $filename = 'product-image.jpg';

        $file_array = [ 'name' => sanitize_file_name( $filename ), 'tmp_name' => $tmp ];
        $att_id     = media_handle_sideload( $file_array, $product_id );

        @unlink( $tmp );

        if ( ! is_wp_error( $att_id ) ) {
            set_post_thumbnail( $product_id, $att_id );
        }
    }

    /**
     * Delete ALL products
     */
    public function delete_all_products() {
        set_time_limit( 600 );
        $ids   = get_posts( [ 'post_type' => 'product', 'posts_per_page' => -1, 'fields' => 'ids', 'post_status' => 'any' ] );
        $total = count( $ids );
        $deleted = 0;

        foreach ( $ids as $id ) {
            wp_delete_post( $id, true );
            $deleted++;
            if ( $deleted % 100 === 0 ) { wp_cache_flush(); }
        }

        return [ 'deleted' => $deleted, 'total' => $total ];
    }

    // ── Private helpers ──

    private function assign_category( $product_id, $cat_name ) {
        $cat_name = trim( $cat_name );
        if ( empty( $cat_name ) ) return;
        $term = get_term_by( 'name', $cat_name, 'product_cat' );
        if ( ! $term ) {
            $new = wp_insert_term( $cat_name, 'product_cat' );
            if ( ! is_wp_error( $new ) ) wp_set_object_terms( $product_id, [ $new['term_id'] ], 'product_cat' );
        } else {
            wp_set_object_terms( $product_id, [ $term->term_id ], 'product_cat' );
        }
    }

    private function assign_tag( $product_id, $tag_name ) {
        $tag_name = trim( $tag_name );
        if ( empty( $tag_name ) ) return;
        $term = get_term_by( 'name', $tag_name, 'product_tag' );
        if ( ! $term ) {
            $new = wp_insert_term( $tag_name, 'product_tag' );
            if ( ! is_wp_error( $new ) ) wp_set_object_terms( $product_id, [ $new['term_id'] ], 'product_tag' );
        } else {
            wp_set_object_terms( $product_id, [ $term->term_id ], 'product_tag' );
        }
    }

    private function attach_image( $product_id, $sku ) {
        $exts = [ 'jpg', 'jpeg', 'png', 'gif', 'webp', 'JPG', 'JPEG', 'PNG' ];
        foreach ( $exts as $ext ) {
            $path = $this->image_folder . $sku . '.' . $ext;
            if ( file_exists( $path ) ) {
                $att_id = $this->upload_image( $path, $product_id );
                if ( $att_id ) set_post_thumbnail( $product_id, $att_id );
                return;
            }
        }
    }

    private function upload_image( $image_path, $product_id ) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $filename = basename( $image_path );
        $upload   = wp_upload_bits( $filename, null, file_get_contents( $image_path ) );
        if ( $upload['error'] ) return false;

        $type  = wp_check_filetype( $filename, null );
        $att   = wp_insert_attachment( [
            'post_mime_type' => $type['type'],
            'post_title'     => sanitize_file_name( $filename ),
            'post_content'   => '',
            'post_status'    => 'inherit',
        ], $upload['file'], $product_id );

        if ( is_wp_error( $att ) ) return false;

        wp_update_attachment_metadata( $att, wp_generate_attachment_metadata( $att, $upload['file'] ) );
        return $att;
    }
}
