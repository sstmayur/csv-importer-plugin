<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * CIWOO_File_Manager
 * Handles multiple CSV file uploads, listing, deletion.
 */
class CIWOO_File_Manager {

    private $logger;

    public function __construct( $logger ) {
        $this->logger = $logger;
    }

    private function csv_folder() {
        return trailingslashit( wp_upload_dir()['basedir'] ) . CIWOO_CSV_FOLDER;
    }

    private function image_folder() {
        return trailingslashit( wp_upload_dir()['basedir'] ) . CIWOO_IMAGE_FOLDER;
    }

    /**
     * Upload one or more CSV files
     * Accepts $_FILES key. Files are saved with their original name (sanitized).
     * Optionally a custom name can be passed.
     */
    public function upload_csv( $file_input_key, $custom_name = '' ) {
        if ( empty( $_FILES[ $file_input_key ]['name'] ) ) {
            return [ 'success' => false, 'error' => 'No file selected.' ];
        }

        $folder = $this->csv_folder();
        wp_mkdir_p( $folder );

        $uploaded = [];
        $errors   = [];

        // Support multiple files from the same input
        $files = $_FILES[ $file_input_key ];
        $is_multi = is_array( $files['name'] );

        if ( ! $is_multi ) {
            // Wrap single file into array structure
            $files = [
                'name'     => [ $files['name'] ],
                'tmp_name' => [ $files['tmp_name'] ],
                'error'    => [ $files['error'] ],
                'size'     => [ $files['size'] ],
            ];
        }

        foreach ( $files['name'] as $i => $original_name ) {
            if ( $files['error'][ $i ] !== UPLOAD_ERR_OK ) {
                $errors[] = 'Upload error for: ' . esc_html( $original_name );
                continue;
            }

            // Determine filename
            if ( ! empty( $custom_name ) && count( $files['name'] ) === 1 ) {
                $filename = sanitize_file_name( $custom_name );
                if ( ! str_ends_with( strtolower( $filename ), '.csv' ) ) {
                    $filename .= '.csv';
                }
            } else {
                $filename = sanitize_file_name( $original_name );
            }

            // Only allow .csv
            if ( strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) ) !== 'csv' ) {
                $errors[] = esc_html( $filename ) . ' is not a CSV file.';
                continue;
            }

            $dest = $folder . $filename;
            if ( move_uploaded_file( $files['tmp_name'][ $i ], $dest ) ) {
                $uploaded[] = $filename;
                $this->logger->info( "CSV uploaded: {$filename}" );
            } else {
                $errors[] = 'Failed to save: ' . esc_html( $filename );
                $this->logger->error( "Failed to move uploaded file: {$filename}" );
            }
        }

        return [ 'success' => ! empty( $uploaded ), 'uploaded' => $uploaded, 'errors' => $errors ];
    }

    /**
     * Upload images ZIP
     */
    public function upload_images_zip( $file_input_key ) {
        if ( empty( $_FILES[ $file_input_key ]['name'] ) ) {
            return [ 'success' => false, 'error' => 'No file selected.' ];
        }

        $file = $_FILES[ $file_input_key ];
        if ( $file['error'] !== UPLOAD_ERR_OK ) {
            return [ 'success' => false, 'error' => 'Upload error.' ];
        }

        $ext = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
        if ( $ext !== 'zip' ) {
            return [ 'success' => false, 'error' => 'Only ZIP files allowed.' ];
        }

        $image_folder = $this->image_folder();
        wp_mkdir_p( $image_folder );

        if ( ! class_exists( 'ZipArchive' ) ) {
            return [ 'success' => false, 'error' => 'ZipArchive not available on server.' ];
        }

        $zip = new ZipArchive();
        if ( $zip->open( $file['tmp_name'] ) !== true ) {
            return [ 'success' => false, 'error' => 'Could not open ZIP file.' ];
        }

        $allowed_ext  = [ 'jpg', 'jpeg', 'png', 'gif', 'webp' ];
        $extracted    = 0;
        $skipped      = 0;

        for ( $i = 0; $i < $zip->numFiles; $i++ ) {
            $name = $zip->getNameIndex( $i );
            $base = basename( $name );
            $fext = strtolower( pathinfo( $base, PATHINFO_EXTENSION ) );

            if ( in_array( $fext, $allowed_ext, true ) && $base && $base[0] !== '.' ) {
                $contents = $zip->getFromIndex( $i );
                if ( $contents !== false ) {
                    file_put_contents( $image_folder . sanitize_file_name( $base ), $contents );
                    $extracted++;
                }
            } else {
                $skipped++;
            }
        }

        $zip->close();
        $this->logger->info( "Images ZIP extracted: {$extracted} images, {$skipped} skipped" );
        return [ 'success' => true, 'extracted' => $extracted, 'skipped' => $skipped ];
    }

    /**
     * List all CSV files in upload folder
     */
    public function list_csv_files() {
        $folder = $this->csv_folder();
        $files  = glob( $folder . '*.csv' );
        if ( ! $files ) return [];

        $result = [];
        foreach ( $files as $path ) {
            $result[] = [
                'name'     => basename( $path ),
                'path'     => $path,
                'size'     => size_format( filesize( $path ) ),
                'modified' => date( 'M d, Y H:i', filemtime( $path ) ),
                'rows'     => $this->count_csv_rows( $path ),
            ];
        }
        return $result;
    }

    /**
     * Delete a CSV file by name
     */
    public function delete_csv_file( $filename ) {
        $filename = sanitize_file_name( basename( $filename ) );
        $path     = $this->csv_folder() . $filename;
        if ( file_exists( $path ) ) {
            wp_delete_file( $path );
            $this->logger->info( "CSV deleted: {$filename}" );
            return true;
        }
        return false;
    }

    /**
     * Count data rows (excluding header)
     */
    private function count_csv_rows( $path ) {
        $count = 0;
        $handle = fopen( $path, 'r' );
        if ( $handle ) {
            fgetcsv( $handle ); // skip header
            while ( fgetcsv( $handle ) !== false ) { $count++; }
            fclose( $handle );
        }
        return $count;
    }

    /**
     * Detect columns from a CSV file
     */
    public function detect_columns( $filename ) {
        $path = $this->csv_folder() . sanitize_file_name( $filename );
        if ( ! file_exists( $path ) ) return [];

        $handle  = fopen( $path, 'r' );
        $headers = fgetcsv( $handle );
        fclose( $handle );

        if ( ! $headers ) return [];

        return array_map( function( $h ) {
            $h = preg_replace( '/^\xEF\xBB\xBF/', '', $h );
            return trim( $h );
        }, $headers );
    }

    /**
     * Image stats
     */
    public function image_stats() {
        $folder = $this->image_folder();
        if ( ! is_dir( $folder ) ) return [ 'count' => 0, 'size_mb' => 0 ];
        $images = glob( $folder . '*.{jpg,jpeg,png,gif,webp}', GLOB_BRACE );
        $size   = 0;
        foreach ( $images as $img ) { $size += filesize( $img ); }
        return [ 'count' => count( $images ), 'size_mb' => round( $size / 1024 / 1024, 2 ) ];
    }
}
