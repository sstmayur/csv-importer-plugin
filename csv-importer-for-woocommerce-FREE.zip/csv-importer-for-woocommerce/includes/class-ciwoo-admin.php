<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class CIWOO_Admin {

    private $logger;
    private $file_manager;

    public function __construct( $logger, $file_manager ) {
        $this->logger       = $logger;
        $this->file_manager = $file_manager;
    }

    public function add_admin_menu() {
        add_submenu_page(
            'woocommerce',
            __( 'CSV Importer', 'csv-importer-woo' ),
            __( 'CSV Importer', 'csv-importer-woo' ),
            'manage_woocommerce',
            'csv-importer-woo',
            [ $this, 'render_page' ]
        );
    }

    public function render_page() {
        $this->handle_form_submissions();
        $active_tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'files';
        $base_url   = admin_url( 'admin.php?page=csv-importer-woo' );
        $tabs = [
            'files'   => '📂 ' . __( 'CSV File',      'csv-importer-woo' ),
            'mapping' => '🔗 ' . __( 'Column Mapping', 'csv-importer-woo' ),
            'import'  => '▶ '  . __( 'Run Import',     'csv-importer-woo' ),
            'images'  => '🖼 '  . __( 'Images',         'csv-importer-woo' ),
            'logs'    => '📋 '  . __( 'Logs',            'csv-importer-woo' ),
            'upgrade' => '⭐ '  . __( 'Upgrade to Pro', 'csv-importer-woo' ),
        ];
        ?>
        <div class="wrap">
            <h1 style="display:flex;align-items:center;gap:10px;">
                <span class="dashicons dashicons-database-import" style="font-size:30px;color:#2271b1;"></span>
                <?php esc_html_e( 'CSV Importer for WooCommerce', 'csv-importer-woo' ); ?>
                <span style="font-size:11px;background:#f0f0f1;padding:2px 8px;border-radius:10px;color:#646970;">FREE</span>
                <span style="font-size:12px;color:#646970;">v<?php echo esc_html( CIWOO_VERSION ); ?></span>
            </h1>

            <?php $this->render_styles(); ?>

            <!-- Pro banner -->
            <div class="ciwoo-pro-banner">
                ⭐ <strong><?php esc_html_e( 'Upgrade to Pro', 'csv-importer-woo' ); ?></strong> —
                <?php esc_html_e( 'Get Auto-Scheduling, Multiple CSV Files, Background Import, Priority Support & more!', 'csv-importer-woo' ); ?>
                <a href="<?php echo esc_url( $base_url . '&tab=upgrade' ); ?>" class="ciwoo-pro-btn"><?php esc_html_e( 'See Pro Features →', 'csv-importer-woo' ); ?></a>
            </div>

            <nav class="ciwoo-tabs">
                <?php foreach ( $tabs as $slug => $label ) : ?>
                    <a href="<?php echo esc_url( $base_url . '&tab=' . $slug ); ?>"
                       class="ciwoo-tab <?php echo $active_tab === $slug ? 'active' : ''; // phpcs:ignore ?><?php echo $slug === 'upgrade' ? ' ciwoo-tab-pro' : ''; ?>">
                        <?php echo esc_html( $label ); ?>
                    </a>
                <?php endforeach; ?>
            </nav>

            <div class="ciwoo-tab-content">
                <?php
                switch ( $active_tab ) {
                    case 'files':   $this->render_files_tab();   break;
                    case 'mapping': $this->render_mapping_tab(); break;
                    case 'import':  $this->render_import_tab();  break;
                    case 'images':  $this->render_images_tab();  break;
                    case 'logs':    $this->render_logs_tab();    break;
                    case 'upgrade': $this->render_upgrade_tab(); break;
                }
                ?>
            </div>
        </div>
        <?php $this->render_javascript( $active_tab ); ?>
        <?php
    }

    private function handle_form_submissions() {
        if ( isset( $_POST['ciwoo_upload_csv'] ) && check_admin_referer( 'ciwoo_upload_csv', 'ciwoo_csv_nonce' ) ) {
            // FREE limit: only 1 file allowed at a time
            $existing = $this->file_manager->list_csv_files();
            if ( count( $existing ) >= CIWOO_MAX_FILES ) {
                add_settings_error( 'ciwoo', 'limit', '⚠️ ' . __( 'Free version allows 1 CSV file. Delete the existing file first, or upgrade to Pro for unlimited files.', 'csv-importer-woo' ), 'warning' );
            } elseif ( ! empty( $_FILES['ciwoo_csv_file']['name'] ) ) {
                $custom_name = isset( $_POST['ciwoo_custom_filename'] ) ? sanitize_text_field( $_POST['ciwoo_custom_filename'] ) : '';
                $result      = $this->file_manager->upload_csv( 'ciwoo_csv_file', $custom_name );
                if ( ! empty( $result['uploaded'] ) ) {
                    add_settings_error( 'ciwoo', 'ok', '✅ ' . __( 'Uploaded: ', 'csv-importer-woo' ) . implode( ', ', $result['uploaded'] ), 'success' );
                }
                foreach ( $result['errors'] as $err ) {
                    add_settings_error( 'ciwoo', 'err', '❌ ' . $err, 'error' );
                }
            }
        }

        if ( isset( $_POST['ciwoo_upload_images'] ) && check_admin_referer( 'ciwoo_upload_images', 'ciwoo_images_nonce' ) ) {
            $result = $this->file_manager->upload_images_zip( 'ciwoo_images_zip' );
            if ( $result['success'] ) {
                add_settings_error( 'ciwoo', 'img_ok', '✅ ' . sprintf( __( 'Extracted %d images.', 'csv-importer-woo' ), $result['extracted'] ), 'success' );
            } else {
                add_settings_error( 'ciwoo', 'img_err', '❌ ' . ( $result['error'] ?? 'Error' ), 'error' );
            }
        }

        settings_errors( 'ciwoo' );
    }

    // ── TABS ──

    private function render_files_tab() {
        $files = $this->file_manager->list_csv_files();
        ?>
        <div class="ciwoo-card">
            <h2>📁 <?php esc_html_e( 'Upload CSV File', 'csv-importer-woo' ); ?></h2>

            <?php if ( count( $files ) >= CIWOO_MAX_FILES ) : ?>
                <div class="notice notice-warning inline" style="margin:0 0 16px;">
                    <p>
                        <?php esc_html_e( 'Free version supports 1 CSV file. Delete the existing file to upload a new one.', 'csv-importer-woo' ); ?>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=csv-importer-woo&tab=upgrade' ) ); ?>">
                            <?php esc_html_e( 'Upgrade to Pro for unlimited files →', 'csv-importer-woo' ); ?>
                        </a>
                    </p>
                </div>
            <?php else : ?>
            <form method="post" enctype="multipart/form-data">
                <?php wp_nonce_field( 'ciwoo_upload_csv', 'ciwoo_csv_nonce' ); ?>
                <div class="ciwoo-form-row">
                    <label><strong><?php esc_html_e( 'Select CSV File', 'csv-importer-woo' ); ?></strong>
                        <p class="description"><?php esc_html_e( 'Upload your WooCommerce product CSV file.', 'csv-importer-woo' ); ?></p>
                        <input type="file" name="ciwoo_csv_file" accept=".csv" style="margin-top:8px;width:100%;max-width:500px;">
                    </label>
                </div>
                <div class="ciwoo-form-row">
                    <label><strong><?php esc_html_e( 'Custom Filename (optional)', 'csv-importer-woo' ); ?></strong>
                        <input type="text" name="ciwoo_custom_filename" placeholder="e.g. products.csv" style="margin-top:6px;width:100%;max-width:400px;">
                    </label>
                </div>
                <button type="submit" name="ciwoo_upload_csv" class="button button-primary">
                    <span class="dashicons dashicons-upload"></span> <?php esc_html_e( 'Upload', 'csv-importer-woo' ); ?>
                </button>
            </form>
            <?php endif; ?>
        </div>

        <div class="ciwoo-card">
            <h2>📄 <?php esc_html_e( 'Your CSV File', 'csv-importer-woo' ); ?></h2>
            <?php if ( empty( $files ) ) : ?>
                <p style="color:#646970;"><?php esc_html_e( 'No CSV file uploaded yet.', 'csv-importer-woo' ); ?></p>
            <?php else : ?>
                <table class="ciwoo-table widefat striped" style="max-width:700px;">
                    <thead><tr>
                        <th><?php esc_html_e( 'File', 'csv-importer-woo' ); ?></th>
                        <th><?php esc_html_e( 'Size', 'csv-importer-woo' ); ?></th>
                        <th><?php esc_html_e( 'Rows', 'csv-importer-woo' ); ?></th>
                        <th><?php esc_html_e( 'Actions', 'csv-importer-woo' ); ?></th>
                    </tr></thead>
                    <tbody>
                        <?php foreach ( $files as $file ) : ?>
                        <tr>
                            <td><strong><?php echo esc_html( $file['name'] ); ?></strong></td>
                            <td><?php echo esc_html( $file['size'] ); ?></td>
                            <td><?php echo esc_html( number_format( $file['rows'] ) ); ?></td>
                            <td>
                                <a href="<?php echo esc_url( admin_url( 'admin-ajax.php?action=ciwoo_download_file&file=' . urlencode( $file['name'] ) . '&_wpnonce=' . wp_create_nonce( 'ciwoo_download_csv' ) ) ); ?>" class="button button-small">⬇ <?php esc_html_e( 'Download', 'csv-importer-woo' ); ?></a>
                                <button class="button button-small ciwoo-delete-file" data-file="<?php echo esc_attr( $file['name'] ); ?>" style="color:#d63638;border-color:#d63638;">🗑 <?php esc_html_e( 'Delete', 'csv-importer-woo' ); ?></button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Pro Upsell -->
        <div class="ciwoo-pro-upsell">
            <span class="ciwoo-pro-lock">🔒</span>
            <div>
                <strong><?php esc_html_e( 'Pro Feature: Multiple CSV Files', 'csv-importer-woo' ); ?></strong>
                <p><?php esc_html_e( 'Upload and manage unlimited CSV files. Import all of them in one click.', 'csv-importer-woo' ); ?></p>
            </div>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=csv-importer-woo&tab=upgrade' ) ); ?>" class="ciwoo-pro-btn">Upgrade →</a>
        </div>
        <?php
    }

    private function render_mapping_tab() {
        $files      = $this->file_manager->list_csv_files();
        $file_maps  = get_option( 'ciwoo_file_mappings', [] );
        $global_map = get_option( 'ciwoo_column_mapping', [] );

        $wc_fields = [
            'sku'              => [ 'label' => 'SKU',              'required' => true,  'icon' => '🔑' ],
            'name'             => [ 'label' => 'Product Name',     'required' => true,  'icon' => '📦' ],
            'price'            => [ 'label' => 'Price',            'required' => true,  'icon' => '💰' ],
            'description'      => [ 'label' => 'Description',      'required' => false, 'icon' => '📝' ],
            'short_description'=> [ 'label' => 'Short Description','required' => false, 'icon' => '📄' ],
            'stock'            => [ 'label' => 'Stock Quantity',   'required' => false, 'icon' => '📊' ],
            'category'         => [ 'label' => 'Category',         'required' => false, 'icon' => '🗂' ],
            'group'            => [ 'label' => 'Group / Tag',      'required' => false, 'icon' => '🏷' ],
            'sale_price'       => [ 'label' => 'Sale Price',       'required' => false, 'icon' => '🔖' ],
            'weight'           => [ 'label' => 'Weight',           'required' => false, 'icon' => '⚖' ],
            'image_url'        => [ 'label' => 'Image URL',        'required' => false, 'icon' => '🖼' ],
        ];
        ?>
        <div class="ciwoo-card">
            <h2>🔗 <?php esc_html_e( 'Column Mapping', 'csv-importer-woo' ); ?></h2>
            <?php if ( empty( $files ) ) : ?>
                <div class="notice notice-warning inline"><p><?php esc_html_e( 'Upload a CSV file first.', 'csv-importer-woo' ); ?></p></div>
            <?php else : ?>
            <p><?php esc_html_e( 'Select your CSV file, click "Load Columns", then match each column to a WooCommerce field.', 'csv-importer-woo' ); ?></p>

            <div class="ciwoo-step-box">
                <div class="ciwoo-step-num">1</div>
                <div style="flex:1">
                    <strong><?php esc_html_e( 'Select CSV File', 'csv-importer-woo' ); ?></strong>
                    <div style="margin-top:10px;display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                        <select id="ciwoo-mapping-file" style="min-width:260px;height:36px;">
                            <option value=""><?php esc_html_e( '— Choose file —', 'csv-importer-woo' ); ?></option>
                            <?php foreach ( $files as $file ) : ?>
                                <option value="<?php echo esc_attr( $file['name'] ); ?>"><?php echo esc_html( $file['name'] ); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="button" class="button button-primary" id="ciwoo-load-columns" disabled>🔍 <?php esc_html_e( 'Load Columns', 'csv-importer-woo' ); ?></button>
                        <span id="ciwoo-loading-cols" style="display:none;color:#646970;"><span class="spinner is-active" style="float:none;vertical-align:middle;"></span></span>
                    </div>
                </div>
            </div>

            <div id="ciwoo-mapping-ui" style="display:none;margin-top:20px;">
                <div class="ciwoo-step-box" style="align-items:flex-start;">
                    <div class="ciwoo-step-num">2</div>
                    <div style="flex:1">
                        <strong><?php esc_html_e( 'Match CSV Columns to WooCommerce Fields', 'csv-importer-woo' ); ?></strong>
                        <div class="ciwoo-mapping-wrapper" style="margin-top:14px;">
                            <div class="ciwoo-mapping-section-title">🔴 <?php esc_html_e( 'Required Fields', 'csv-importer-woo' ); ?></div>
                            <?php foreach ( $wc_fields as $fk => $fi ) : if ( ! $fi['required'] ) continue; ?>
                            <div class="ciwoo-mapping-row required" data-field="<?php echo esc_attr( $fk ); ?>">
                                <div class="ciwoo-wc-field"><span class="ciwoo-field-icon"><?php echo esc_html( $fi['icon'] ); ?></span><div><strong><?php echo esc_html( $fi['label'] ); ?></strong><span class="ciwoo-required-badge">Required</span></div></div>
                                <div class="ciwoo-arrow">→</div>
                                <div class="ciwoo-csv-col">
                                    <select class="ciwoo-col-select" data-field="<?php echo esc_attr( $fk ); ?>" style="width:100%;max-width:320px;">
                                        <option value=""><?php esc_html_e( '— Select column —', 'csv-importer-woo' ); ?></option>
                                    </select>
                                </div>
                            </div>
                            <?php endforeach; ?>
                            <div class="ciwoo-mapping-section-title" style="margin-top:16px;">🔵 <?php esc_html_e( 'Optional Fields', 'csv-importer-woo' ); ?></div>
                            <?php foreach ( $wc_fields as $fk => $fi ) : if ( $fi['required'] ) continue; ?>
                            <div class="ciwoo-mapping-row" data-field="<?php echo esc_attr( $fk ); ?>">
                                <div class="ciwoo-wc-field"><span class="ciwoo-field-icon"><?php echo esc_html( $fi['icon'] ); ?></span><strong><?php echo esc_html( $fi['label'] ); ?></strong></div>
                                <div class="ciwoo-arrow">→</div>
                                <div class="ciwoo-csv-col">
                                    <select class="ciwoo-col-select" data-field="<?php echo esc_attr( $fk ); ?>" style="width:100%;max-width:320px;">
                                        <option value=""><?php esc_html_e( 'Do Not Import', 'csv-importer-woo' ); ?></option>
                                    </select>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <div id="ciwoo-unmapped-section" style="display:none;margin-top:16px;padding:12px;background:#fff8e1;border-left:4px solid #f59e0b;border-radius:4px;">
                            <strong>📋 <?php esc_html_e( 'Unmapped columns:', 'csv-importer-woo' ); ?></strong>
                            <div id="ciwoo-unmapped-cols" style="margin-top:8px;display:flex;flex-wrap:wrap;gap:6px;"></div>
                        </div>
                    </div>
                </div>

                <div class="ciwoo-step-box" style="margin-top:12px;">
                    <div class="ciwoo-step-num">3</div>
                    <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
                        <button type="button" class="button button-primary button-large" id="ciwoo-save-mapping">💾 <?php esc_html_e( 'Save Mapping', 'csv-importer-woo' ); ?></button>
                        <span id="ciwoo-mapping-status" style="color:#00a32a;font-weight:600;display:none;">✅ <?php esc_html_e( 'Saved!', 'csv-importer-woo' ); ?></span>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <script>
        var ciwooWcFields  = <?php echo wp_json_encode( $wc_fields ); ?>;
        var ciwooFileMaps  = <?php echo wp_json_encode( $file_maps ); ?>;
        var ciwooGlobalMap = <?php echo wp_json_encode( $global_map ); ?>;
        </script>
        <?php
    }

    private function render_import_tab() {
        $files = $this->file_manager->list_csv_files();
        ?>
        <div class="ciwoo-card">
            <h2>▶ <?php esc_html_e( 'Run Import', 'csv-importer-woo' ); ?></h2>
            <?php if ( empty( $files ) ) : ?>
                <div class="notice notice-warning inline"><p><?php esc_html_e( 'Upload a CSV file first.', 'csv-importer-woo' ); ?></p></div>
            <?php else : ?>
                <?php foreach ( $files as $file ) : ?>
                <div style="padding:16px;background:#f8f9fa;border:1px solid #e2e4e7;border-radius:6px;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
                    <div>
                        <strong><?php echo esc_html( $file['name'] ); ?></strong>
                        <span style="color:#646970;margin-left:8px;"><?php echo esc_html( number_format( $file['rows'] ) ); ?> rows</span>
                    </div>
                    <button type="button" class="button button-primary ciwoo-run-import" data-file="<?php echo esc_attr( $file['name'] ); ?>">
                        <span class="dashicons dashicons-controls-play"></span> <?php esc_html_e( 'Import Now', 'csv-importer-woo' ); ?>
                    </button>
                </div>
                <?php endforeach; ?>
                <div id="ciwoo-import-progress" style="display:none;margin-top:16px;"></div>
                <div id="ciwoo-import-result"   style="display:none;margin-top:16px;"></div>
            <?php endif; ?>
        </div>

        <!-- Pro: Auto-Schedule upsell -->
        <div class="ciwoo-pro-upsell">
            <span class="ciwoo-pro-lock">🔒</span>
            <div>
                <strong><?php esc_html_e( 'Pro Feature: Auto-Scheduling', 'csv-importer-woo' ); ?></strong>
                <p><?php esc_html_e( 'Set imports to run automatically — hourly, daily, or weekly. No manual clicking needed.', 'csv-importer-woo' ); ?></p>
            </div>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=csv-importer-woo&tab=upgrade' ) ); ?>" class="ciwoo-pro-btn">Upgrade →</a>
        </div>

        <!-- Pro: Background import upsell -->
        <div class="ciwoo-pro-upsell" style="margin-top:12px;">
            <span class="ciwoo-pro-lock">🔒</span>
            <div>
                <strong><?php esc_html_e( 'Pro Feature: Background Import', 'csv-importer-woo' ); ?></strong>
                <p><?php esc_html_e( 'Large files? Pro runs imports in the background — no browser timeout, no page waiting.', 'csv-importer-woo' ); ?></p>
            </div>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=csv-importer-woo&tab=upgrade' ) ); ?>" class="ciwoo-pro-btn">Upgrade →</a>
        </div>
        <?php
    }

    private function render_images_tab() {
        $stats = $this->file_manager->image_stats();
        ?>
        <div class="ciwoo-card">
            <h2>🖼 <?php esc_html_e( 'Upload Product Images', 'csv-importer-woo' ); ?></h2>
            <div style="padding:12px;background:#f6f7f7;border-left:4px solid #2271b1;border-radius:4px;margin-bottom:20px;">
                🖼 <?php echo esc_html( $stats['count'] ); ?> <?php esc_html_e( 'images', 'csv-importer-woo' ); ?> | 💾 <?php echo esc_html( $stats['size_mb'] ); ?> MB
            </div>
            <form method="post" enctype="multipart/form-data">
                <?php wp_nonce_field( 'ciwoo_upload_images', 'ciwoo_images_nonce' ); ?>
                <div class="ciwoo-form-row">
                    <label><strong><?php esc_html_e( 'Upload Images ZIP', 'csv-importer-woo' ); ?></strong>
                        <p class="description"><?php esc_html_e( 'Name each image after the product SKU. e.g. SKU001.jpg', 'csv-importer-woo' ); ?></p>
                        <input type="file" name="ciwoo_images_zip" accept=".zip" style="margin-top:8px;width:100%;max-width:500px;">
                    </label>
                </div>
                <button type="submit" name="ciwoo_upload_images" class="button button-primary">⬆ <?php esc_html_e( 'Upload ZIP', 'csv-importer-woo' ); ?></button>
            </form>
        </div>
        <?php
    }

    private function render_logs_tab() {
        ?>
        <div class="ciwoo-card">
            <h2>📋 <?php esc_html_e( 'Import Logs', 'csv-importer-woo' ); ?></h2>
            <button type="button" class="button button-secondary" id="ciwoo-view-logs">👁 <?php esc_html_e( "Load Today's Logs", 'csv-importer-woo' ); ?></button>
            <div id="ciwoo-log-output" style="display:none;margin-top:16px;">
                <pre style="background:#1d2327;color:#7dc17e;padding:20px;overflow:auto;max-height:450px;border-radius:6px;font-size:12px;line-height:1.6;"></pre>
            </div>
        </div>
        <?php
    }

    private function render_upgrade_tab() {
        $pro_url = 'https://your-website.com/csv-importer-pro'; // TODO: replace with real URL
        ?>
        <div class="ciwoo-card" style="max-width:860px;">
            <h2 style="font-size:22px;">⭐ <?php esc_html_e( 'Upgrade to CSV Importer Pro', 'csv-importer-woo' ); ?></h2>
            <p style="font-size:15px;color:#646970;"><?php esc_html_e( 'Supercharge your WooCommerce product imports with powerful Pro features.', 'csv-importer-woo' ); ?></p>

            <div class="ciwoo-compare-grid">
                <!-- Free column -->
                <div class="ciwoo-compare-col">
                    <div class="ciwoo-compare-header free"><?php esc_html_e( 'FREE', 'csv-importer-woo' ); ?></div>
                    <?php
                    $free_features = [
                        [ true,  'Import products from CSV' ],
                        [ true,  'Smart column auto-detection' ],
                        [ true,  'Custom column mapping' ],
                        [ true,  'Create & update products' ],
                        [ true,  'Product images (ZIP upload)' ],
                        [ true,  'Import logs' ],
                        [ false, '1 CSV file only' ],
                        [ false, 'Batch size: 20 products' ],
                        [ false, 'No auto-scheduling' ],
                        [ false, 'No background import' ],
                        [ false, 'No FTP/URL import' ],
                        [ false, 'No priority support' ],
                    ];
                    foreach ( $free_features as $f ) :
                        $icon = $f[0] ? '<span style="color:#00a32a;">✅</span>' : '<span style="color:#d63638;">✗</span>';
                    ?>
                    <div class="ciwoo-compare-row">
                        <?php echo wp_kses( $icon, [ 'span' => [ 'style' => [] ] ] ); ?>
                        <?php echo esc_html( $f[1] ); ?>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- Pro column -->
                <div class="ciwoo-compare-col featured">
                    <div class="ciwoo-compare-header pro">PRO ⭐</div>
                    <?php
                    $pro_features = [
                        [ true, 'Import products from CSV' ],
                        [ true, 'Smart column auto-detection' ],
                        [ true, 'Custom column mapping (per-file)' ],
                        [ true, 'Create & update products' ],
                        [ true, 'Product images (ZIP + URL)' ],
                        [ true, 'Detailed import logs' ],
                        [ true, 'Unlimited CSV files' ],
                        [ true, 'Batch size: 50 products' ],
                        [ true, '⏰ Auto-Schedule (hourly/daily/weekly)' ],
                        [ true, '🚀 Background import (no timeout)' ],
                        [ true, '🔗 Import from FTP / URL' ],
                        [ true, '🎧 Priority email support' ],
                    ];
                    foreach ( $pro_features as $f ) :
                    ?>
                    <div class="ciwoo-compare-row">
                        <span style="color:#00a32a;">✅</span>
                        <?php echo esc_html( $f[1] ); ?>
                    </div>
                    <?php endforeach; ?>
                    <div style="text-align:center;margin-top:24px;">
                        <a href="<?php echo esc_url( $pro_url ); ?>" target="_blank" class="button button-primary button-large" style="background:#f59e0b;border-color:#d97706;font-size:15px;padding:10px 28px;height:auto;">
                            🚀 <?php esc_html_e( 'Get Pro Now →', 'csv-importer-woo' ); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    // ── STYLES ──
    private function render_styles() { ?>
        <style>
        .ciwoo-pro-banner { background:linear-gradient(135deg,#f59e0b,#d97706); color:#fff; padding:12px 20px; border-radius:6px; margin:16px 0; display:flex; align-items:center; gap:12px; flex-wrap:wrap; font-size:13px; }
        .ciwoo-pro-btn { background:#fff; color:#d97706; padding:5px 14px; border-radius:4px; text-decoration:none; font-weight:700; font-size:12px; white-space:nowrap; }
        .ciwoo-pro-btn:hover { background:#fffbf0; color:#b45309; }
        .ciwoo-tabs { display:flex; gap:4px; margin:16px 0 0; border-bottom:2px solid #c3c4c7; flex-wrap:wrap; }
        .ciwoo-tab { padding:9px 16px; text-decoration:none; color:#1d2327; background:#f0f0f1; border:1px solid #c3c4c7; border-bottom:none; border-radius:4px 4px 0 0; font-size:13px; font-weight:500; }
        .ciwoo-tab:hover { background:#fff; color:#2271b1; }
        .ciwoo-tab.active { background:#fff; color:#2271b1; border-bottom:2px solid #fff; margin-bottom:-2px; }
        .ciwoo-tab.ciwoo-tab-pro { background:#fef3c7; color:#92400e; border-color:#fcd34d; }
        .ciwoo-tab.ciwoo-tab-pro.active { background:#fff; }
        .ciwoo-tab-content { background:#fff; border:1px solid #c3c4c7; border-top:none; padding:24px; border-radius:0 0 4px 4px; }
        .ciwoo-card { background:#fff; border:1px solid #e2e4e7; border-radius:6px; padding:22px; margin-bottom:20px; box-shadow:0 1px 3px rgba(0,0,0,.04); }
        .ciwoo-card h2 { margin:0 0 14px; font-size:16px; border-bottom:1px solid #f0f0f1; padding-bottom:10px; }
        .ciwoo-form-row { margin-bottom:18px; }
        .ciwoo-form-row .description { color:#646970; font-size:12px; margin:3px 0 0; font-style:italic; }
        .ciwoo-table th { background:#f6f7f7; }
        .ciwoo-table th, .ciwoo-table td { padding:9px 12px; vertical-align:middle; }
        .ciwoo-pro-upsell { display:flex; align-items:center; gap:16px; padding:16px 20px; background:#fffbf0; border:1px dashed #f59e0b; border-radius:6px; }
        .ciwoo-pro-lock { font-size:24px; }
        .ciwoo-pro-upsell p { margin:4px 0 0; color:#646970; font-size:13px; }
        .ciwoo-step-box { display:flex; align-items:center; gap:14px; padding:16px 18px; background:#f8f9fa; border:1px solid #e2e4e7; border-radius:8px; margin-bottom:10px; }
        .ciwoo-step-num { width:30px; height:30px; border-radius:50%; background:#2271b1; color:#fff; font-weight:700; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
        .ciwoo-mapping-wrapper { border:1px solid #e2e4e7; border-radius:6px; overflow:hidden; }
        .ciwoo-mapping-section-title { padding:7px 14px; background:#f0f0f1; font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.5px; color:#646970; }
        .ciwoo-mapping-row { display:grid; grid-template-columns:240px 36px 1fr; align-items:center; padding:10px 14px; border-bottom:1px solid #f0f0f1; }
        .ciwoo-mapping-row:last-child { border-bottom:none; }
        .ciwoo-mapping-row.required { background:#fffef5; }
        .ciwoo-mapping-row.mapped { background:#f0fdf4 !important; }
        .ciwoo-wc-field { display:flex; align-items:center; gap:8px; }
        .ciwoo-field-icon { font-size:16px; width:22px; text-align:center; }
        .ciwoo-required-badge { background:#d63638; color:#fff; font-size:10px; padding:1px 6px; border-radius:10px; margin-left:5px; font-weight:600; }
        .ciwoo-arrow { text-align:center; color:#2271b1; font-size:18px; font-weight:700; }
        .ciwoo-col-preview { font-size:11px; color:#00a32a; margin-top:3px; font-weight:600; }
        .ciwoo-unmapped-tag { background:#f3f4f6; border:1px solid #d1d5db; padding:2px 9px; border-radius:12px; font-size:12px; color:#374151; }
        /* Compare table */
        .ciwoo-compare-grid { display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-top:24px; }
        .ciwoo-compare-col { border:1px solid #e2e4e7; border-radius:8px; overflow:hidden; }
        .ciwoo-compare-col.featured { border-color:#f59e0b; box-shadow:0 4px 16px rgba(245,158,11,.2); }
        .ciwoo-compare-header { padding:16px; text-align:center; font-size:18px; font-weight:700; }
        .ciwoo-compare-header.free { background:#f6f7f7; color:#646970; }
        .ciwoo-compare-header.pro  { background:linear-gradient(135deg,#f59e0b,#d97706); color:#fff; }
        .ciwoo-compare-row { padding:10px 16px; border-bottom:1px solid #f0f0f1; font-size:13px; display:flex; gap:10px; align-items:flex-start; }
        .ciwoo-compare-row:last-child { border-bottom:none; }
        @media (max-width:700px) { .ciwoo-compare-grid { grid-template-columns:1fr; } .ciwoo-mapping-row { grid-template-columns:1fr; } }
        </style>
    <?php }

    // ── JAVASCRIPT ──
    private function render_javascript( $active_tab ) { ?>
        <script>
        jQuery(document).ready(function($){
            var nonce = '<?php echo wp_create_nonce( 'ciwoo_ajax' ); ?>';

            // Delete CSV file
            $(document).on('click', '.ciwoo-delete-file', function(){
                if (!confirm('Delete ' + $(this).data('file') + '?')) return;
                $.post(ajaxurl, { action:'ciwoo_delete_csv_file', file:$(this).data('file'), _ajax_nonce:nonce }, function(r){
                    if (r.success) location.reload(); else alert(r.data);
                });
            });

            // Mapping: enable Load button
            $('#ciwoo-mapping-file').on('change', function(){
                $('#ciwoo-load-columns').prop('disabled', !$(this).val());
                if (!$(this).val()) $('#ciwoo-mapping-ui').hide();
            });

            // Load columns
            var detectedCols = [];
            var fieldAliases = {
                'sku':['sku','item number','itemnumber','item code','product id'],
                'name':['name','product name','title'],
                'price':['price','sales price','salesprice','regular price','unit price'],
                'description':['description','product description','desc'],
                'short_description':['short description','short_description','summary'],
                'stock':['stock','stock on hand','qty','quantity','inventory'],
                'category':['category','product category','cat'],
                'group':['group','product group','tag'],
                'sale_price':['sale price','sale_price','discount price'],
                'weight':['weight','wt'],
                'image_url':['image','image url','photo','picture'],
            };

            $('#ciwoo-load-columns').on('click', function(){
                var file = $('#ciwoo-mapping-file').val();
                if (!file) return;
                $('#ciwoo-loading-cols').show();
                $(this).prop('disabled', true);
                $.post(ajaxurl, { action:'ciwoo_detect_columns', file:file, _ajax_nonce:nonce }, function(r){
                    $('#ciwoo-loading-cols').hide();
                    $('#ciwoo-load-columns').prop('disabled', false);
                    if (!r.success || !r.data.length) { alert('Could not detect columns.'); return; }
                    detectedCols = r.data;
                    var savedMap = (typeof ciwooFileMaps !== 'undefined' && ciwooFileMaps[file]) ? ciwooFileMaps[file] : (typeof ciwooGlobalMap !== 'undefined' ? ciwooGlobalMap : {});
                    var reqOpts = '<option value="">— Select CSV column —</option>';
                    var optOpts = '<option value="">Do Not Import</option>';
                    $.each(detectedCols, function(i, col){ reqOpts += '<option value="'+esc(col)+'">'+esc(col)+'</option>'; optOpts += '<option value="'+esc(col)+'">'+esc(col)+'</option>'; });

                    $('.ciwoo-col-select').each(function(){
                        var field = $(this).data('field');
                        var isReq = $(this).closest('.ciwoo-mapping-row').hasClass('required');
                        $(this).html(isReq ? reqOpts : optOpts);
                        var saved = savedMap[field] || '';
                        if (saved && detectedCols.indexOf(saved) !== -1) {
                            $(this).val(saved);
                        } else {
                            var auto = smartMatch(field, detectedCols);
                            if (auto) $(this).val(auto);
                        }
                        updateRow($(this));
                    });
                    updateUnmapped();
                    $('#ciwoo-mapping-ui').slideDown(200);
                });
            });

            $(document).on('change', '.ciwoo-col-select', function(){ updateRow($(this)); updateUnmapped(); });

            function smartMatch(field, cols) {
                var aliases = fieldAliases[field] || [];
                var lower = cols.map(function(c){ return c.toLowerCase().trim(); });
                for (var i=0;i<aliases.length;i++){ var idx=lower.indexOf(aliases[i]); if(idx!==-1) return cols[idx]; }
                return null;
            }
            function updateRow($sel) {
                var $row = $sel.closest('.ciwoo-mapping-row');
                $row.find('.ciwoo-col-preview').remove();
                if ($sel.val()) {
                    $sel.css({'border-color':'#00a32a','background':'#f0fdf4'});
                    $row.addClass('mapped');
                    $sel.after('<div class="ciwoo-col-preview">✅ '+esc($sel.val())+'</div>');
                } else {
                    $sel.css({'border-color':'','background':''});
                    $row.removeClass('mapped');
                }
            }
            function updateUnmapped() {
                var used = [];
                $('.ciwoo-col-select').each(function(){ if($(this).val()) used.push($(this).val()); });
                var unmapped = detectedCols.filter(function(c){ return used.indexOf(c)===-1; });
                var $sec = $('#ciwoo-unmapped-section'), $list = $('#ciwoo-unmapped-cols');
                $list.empty();
                if (unmapped.length) { $.each(unmapped,function(i,c){ $list.append('<span class="ciwoo-unmapped-tag">'+esc(c)+'</span>'); }); $sec.show(); }
                else { $sec.hide(); }
            }

            // Save mapping
            $('#ciwoo-save-mapping').on('click', function(){
                var file = $('#ciwoo-mapping-file').val();
                var mapping = {};
                $('.ciwoo-col-select').each(function(){ if($(this).val()) mapping[$(this).data('field')] = $(this).val(); });
                var missing = ['sku','name','price'].filter(function(f){ return !mapping[f]; });
                if (missing.length) { alert('Map required fields: '+missing.join(', ')); return; }
                $(this).prop('disabled',true).text('Saving...');
                $.post(ajaxurl,{action:'ciwoo_save_mapping',file:file,mapping:mapping,_ajax_nonce:nonce},function(r){
                    $('#ciwoo-save-mapping').prop('disabled',false).html('💾 Save Mapping');
                    if(r.success){ $('#ciwoo-mapping-status').show().delay(2500).fadeOut(); } else { alert(r.data); }
                });
            });

            // Run import
            var importRunning = false;
            $(document).on('click', '.ciwoo-run-import', function(){
                if (importRunning) { alert('Import already running!'); return; }
                var file = $(this).data('file');
                if (!confirm('Import ' + file + '?')) return;
                importRunning = true;
                var $btn = $(this).prop('disabled',true);
                var batch = 1, offset = 0, totals = {created:0,updated:0,skipped:0,errors:0};
                function runBatch() {
                    $('#ciwoo-import-progress').show().html('<div style="padding:14px;background:#f0f6fc;border-left:4px solid #2271b1;border-radius:4px;"><strong>📦 Batch '+batch+'...</strong><div style="background:#ddd;border-radius:4px;height:14px;margin:8px 0;"><div id="ciwoo-pbar" style="background:#2271b1;height:100%;border-radius:4px;width:0%;transition:width .3s;"></div></div><span id="ciwoo-ptext">Processing...</span></div>');
                    $.ajax({ url:ajaxurl, type:'POST', timeout:120000,
                        data:{action:'ciwoo_manual_import',file:file,batch:batch,offset:offset,_ajax_nonce:nonce},
                        success:function(r){
                            if (!r.success){ showErr(r.data||'Error'); return; }
                            var d=r.data;
                            totals.created+=d.created||0; totals.updated+=d.updated||0; totals.skipped+=d.skipped||0; totals.errors+=d.errors||0;
                            var pct=d.total_rows>0?Math.min(100,Math.round(d.processed/d.total_rows*100)):100;
                            $('#ciwoo-pbar').css('width',pct+'%');
                            $('#ciwoo-ptext').text('Processed: '+d.processed+'/'+(d.total_rows||'?')+' ('+pct+'%)');
                            if (d.has_more){ batch++; offset=d.offset; setTimeout(runBatch,800); }
                            else {
                                importRunning=false; $btn.prop('disabled',false);
                                $('#ciwoo-import-progress').hide();
                                $('#ciwoo-import-result').show().html('<div style="padding:18px;background:#d4edda;border-left:4px solid #28a745;border-radius:6px;"><h3 style="margin:0 0 8px;color:#155724;">✅ Import Complete!</h3><p>Created: <strong>'+totals.created+'</strong> | Updated: <strong>'+totals.updated+'</strong> | Skipped: <strong>'+totals.skipped+'</strong> | Errors: <strong>'+totals.errors+'</strong></p></div>');
                            }
                        },
                        error:function(x,s,e){ showErr(s+': '+e); }
                    });
                }
                function showErr(msg){ importRunning=false; $btn.prop('disabled',false); $('#ciwoo-import-progress').hide(); $('#ciwoo-import-result').show().html('<div style="padding:18px;background:#f8d7da;border-left:4px solid #d63638;border-radius:6px;"><h3 style="color:#721c24;">❌ Error</h3><p>'+msg+'</p></div>'); }
                runBatch();
            });

            // View logs
            $('#ciwoo-view-logs').on('click', function(){
                var $out = $('#ciwoo-log-output');
                if ($out.is(':visible')){ $out.hide(); $(this).text("👁 Load Today's Logs"); return; }
                $(this).text('Loading...');
                $.post(ajaxurl,{action:'ciwoo_view_logs',_ajax_nonce:nonce},function(r){ if(r.success){$out.find('pre').text(r.data);$out.show();$('#ciwoo-view-logs').text('Hide Logs');} });
            });

            function esc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
        });
        </script>
    <?php }
}
