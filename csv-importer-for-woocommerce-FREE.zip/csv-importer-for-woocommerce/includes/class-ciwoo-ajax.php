<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class CIWOO_Ajax {

    private $logger;
    private $parser;
    private $product;
    private $file_manager;

    public function __construct( $logger, $parser, $product, $file_manager ) {
        $this->logger       = $logger;
        $this->parser       = $parser;
        $this->product      = $product;
        $this->file_manager = $file_manager;
    }

    public function handle_manual_import() {
        check_ajax_referer( 'ciwoo_ajax', '_ajax_nonce' );
        if ( ! current_user_can( 'manage_woocommerce' ) ) wp_send_json_error( 'Unauthorized' );

        $file   = isset( $_POST['file'] )   ? sanitize_text_field( $_POST['file'] )  : '';
        $offset = isset( $_POST['offset'] ) ? intval( $_POST['offset'] )              : 0;
        $batch  = isset( $_POST['batch'] )  ? intval( $_POST['batch'] )               : 1;

        if ( empty( $file ) ) wp_send_json_error( 'No file specified' );

        set_time_limit( 300 );

        $csv_folder = trailingslashit( wp_upload_dir()['basedir'] ) . CIWOO_CSV_FOLDER;
        $file_path  = $csv_folder . sanitize_file_name( $file );

        if ( ! file_exists( $file_path ) ) wp_send_json_error( 'File not found: ' . esc_html( $file ) );

        $mapping = $this->parser->get_mapping_for_file( $file );
        $raw     = $this->parser->read_raw( $file_path );
        if ( ! $raw ) wp_send_json_error( 'Could not read CSV' );

        $headers    = $raw['headers'];
        $all_rows   = $raw['rows'];
        $total_rows = count( $all_rows );
        $chunk      = array_slice( $all_rows, $offset, CIWOO_BATCH_SIZE );

        $stats = [ 'created' => 0, 'updated' => 0, 'skipped' => 0, 'errors' => 0 ];

        foreach ( $chunk as $row ) {
            if ( count( $headers ) !== count( $row ) ) { $stats['skipped']++; continue; }
            $data   = array_combine( $headers, $row );
            $mapped = $this->parser->map_row( $data, $mapping );
            if ( ! $mapped ) { $stats['skipped']++; continue; }

            $sku         = $mapped['sku'];
            $existing_id = wc_get_product_id_by_sku( $sku );
            if ( ! $existing_id ) {
                global $wpdb;
                $existing_id = $wpdb->get_var( $wpdb->prepare(
                    "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_sku' AND meta_value=%s LIMIT 1", $sku
                ) );
            }

            if ( $existing_id ) {
                $this->product->update_product( $existing_id, $mapped ) ? $stats['updated']++ : $stats['skipped']++;
            } else {
                $this->product->create_product( $mapped ) ? $stats['created']++ : $stats['errors']++;
            }
        }

        $next_offset = $offset + CIWOO_BATCH_SIZE;
        $has_more    = $next_offset < $total_rows;

        wp_send_json_success( [
            'processed'  => $offset + count( $chunk ),
            'created'    => $stats['created'],
            'updated'    => $stats['updated'],
            'skipped'    => $stats['skipped'],
            'errors'     => $stats['errors'],
            'has_more'   => $has_more,
            'total_rows' => $total_rows,
            'offset'     => $next_offset,
        ] );
    }

    public function handle_view_logs() {
        check_ajax_referer( 'ciwoo_ajax', '_ajax_nonce' );
        if ( ! current_user_can( 'manage_woocommerce' ) ) wp_send_json_error( 'Unauthorized' );
        wp_send_json_success( $this->logger->get_recent_logs( 200 ) );
    }

    public function handle_delete_csv_file() {
        check_ajax_referer( 'ciwoo_ajax', '_ajax_nonce' );
        if ( ! current_user_can( 'manage_woocommerce' ) ) wp_send_json_error( 'Unauthorized' );
        $filename = isset( $_POST['file'] ) ? sanitize_text_field( $_POST['file'] ) : '';
        $result   = $this->file_manager->delete_csv_file( $filename );
        $result ? wp_send_json_success( 'Deleted' ) : wp_send_json_error( 'Not found' );
    }

    public function handle_save_mapping() {
        check_ajax_referer( 'ciwoo_ajax', '_ajax_nonce' );
        if ( ! current_user_can( 'manage_woocommerce' ) ) wp_send_json_error( 'Unauthorized' );
        $file    = isset( $_POST['file'] )    ? sanitize_text_field( $_POST['file'] ) : '';
        $mapping = isset( $_POST['mapping'] ) ? (array) $_POST['mapping']             : [];
        $clean   = [];
        foreach ( $mapping as $field => $col ) {
            $clean[ sanitize_key( $field ) ] = sanitize_text_field( $col );
        }
        if ( ! empty( $file ) ) {
            $this->parser->save_mapping_for_file( $file, $clean );
        } else {
            $this->parser->save_global_mapping( $clean );
        }
        wp_send_json_success( 'Mapping saved' );
    }

    public function handle_detect_columns() {
        check_ajax_referer( 'ciwoo_ajax', '_ajax_nonce' );
        if ( ! current_user_can( 'manage_woocommerce' ) ) wp_send_json_error( 'Unauthorized' );
        $file    = isset( $_POST['file'] ) ? sanitize_text_field( $_POST['file'] ) : '';
        $columns = $this->file_manager->detect_columns( $file );
        wp_send_json_success( $columns );
    }

    public function handle_download_file() {
        if ( ! isset( $_GET['_wpnonce'] ) ) wp_die( esc_html__( 'Security check failed.', 'csv-importer-woo' ) );
        check_admin_referer( 'ciwoo_download_csv', '_wpnonce' );
        if ( ! current_user_can( 'manage_woocommerce' ) ) wp_die( esc_html__( 'Unauthorized.', 'csv-importer-woo' ) );
        $filename = isset( $_GET['file'] ) ? sanitize_file_name( basename( $_GET['file'] ) ) : '';
        $folder   = trailingslashit( wp_upload_dir()['basedir'] ) . CIWOO_CSV_FOLDER;
        $path     = $folder . $filename;
        if ( ! file_exists( $path ) ) wp_die( esc_html__( 'File not found.', 'csv-importer-woo' ) );
        header( 'Content-Type: text/csv' );
        header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
        header( 'Content-Length: ' . filesize( $path ) );
        header( 'Pragma: no-cache' );
        readfile( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_readfile
        exit;
    }
}
