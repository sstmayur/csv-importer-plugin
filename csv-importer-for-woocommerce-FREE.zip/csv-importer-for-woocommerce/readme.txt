=== CSV Importer for WooCommerce ===
Contributors: yourwordpressusername
Tags: woocommerce, csv import, product import, bulk import, woocommerce products
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Import WooCommerce products from a CSV file with smart column auto-detection and custom mapping. Simple, fast, free.

== Description ==

**CSV Importer for WooCommerce** makes it easy to bulk import products into your WooCommerce store from any CSV file — no matter what your column names are.

= How It Works =

1. Upload your CSV file
2. Click "Load Columns" — the plugin reads your CSV headers automatically
3. Match each column to the correct WooCommerce field (SKU, Name, Price, etc.)
4. Click Import — done!

= Free Features =

* Upload 1 CSV file
* Smart column auto-detection — reads headers from your CSV
* Custom column mapping — works with any CSV structure
* Auto-match common column names (e.g. "SalesPrice" → Price)
* Create new products or update existing ones (matched by SKU)
* Product images via ZIP upload (named by SKU)
* Import logs
* Batch processing to prevent timeouts

= Pro Features (Upgrade) =

* **Unlimited CSV files** — upload and manage as many files as you need
* **Auto-Scheduling** — run imports automatically (hourly, daily, weekly)
* **Background Import** — large files run in the background, no browser needed
* **No row limits**
* **Priority support**

[Upgrade to Pro →](https://your-website.com/csv-importer-pro)

== Installation ==

1. Upload the `csv-importer-for-woocommerce` folder to `/wp-content/plugins/`
2. Activate from WordPress Plugins page
3. Go to **WooCommerce → CSV Importer**
4. Upload your CSV and configure column mapping

== Frequently Asked Questions ==

= Do I need to rename my CSV columns? =
No. Upload any CSV — the plugin reads all column names automatically and lets you map them yourself.

= What if a product already exists? =
Products are matched by SKU. If found, the product is updated. If not found, a new product is created.

= Is there a row limit? =
The free version processes all rows but in smaller batches. Upgrade to Pro for larger batch sizes and background processing.

== Screenshots ==

1. CSV file upload screen
2. Column mapping — auto-detected columns from your CSV
3. Import running with progress bar

== Changelog ==

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.0 =
Initial release.
